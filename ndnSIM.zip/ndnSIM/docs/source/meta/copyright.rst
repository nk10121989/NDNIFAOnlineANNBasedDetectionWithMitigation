=========
Copyright
=========

ndnSIM and this documentation is:

Copyright © 2011-2015 University of California, Los Angeles

Copyright © 2011-2015 Alexander Afanasyev

-------

See :ref:`license` for complete license and permissions information.
