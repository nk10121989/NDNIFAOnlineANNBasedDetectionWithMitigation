.. _reporting-bugs:

==============
Reporting bugs
==============

Please submit bug reports and feature requests on `redmine <http://redmine.named-data.net/projects/ndnsim?jump=welcome>`_,
or tell us about them on `our mailing list <http://www.lists.cs.ucla.edu/mailman/listinfo/ndnsim>`_ .
