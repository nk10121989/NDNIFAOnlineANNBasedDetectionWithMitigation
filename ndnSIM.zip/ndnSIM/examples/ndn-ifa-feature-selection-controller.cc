#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include <vector>
// ./waf --run "ndn-ifa-feature-selection-controller --traceFileName --mul=2 --traceInterval=1 --Mitigation=false --Normal=false"
using namespace ns3;
class CachePollutionExperiment
{
	public:
	CachePollutionExperiment ();
	void Run ();
	void CommandSetup (int argc, char **argv);
	void PeriodicStatsPrinter (Ptr<Node> node, Time next);
	private:
	std::string traceFileName, csSize;
	double  mul, traceInterval;
        bool mitigation, normal;
};





void CachePollutionExperiment::PeriodicStatsPrinter (Ptr<Node> node, Time next)
{
  Ptr<ndn::Pit> pit = node->GetObject<ndn::Pit> ();
   int count[10]={0};
   for (Ptr<ndn::pit::Entry> entry = pit->Begin (); entry != pit->End (); entry = pit->Next (entry))
    {
       std::set< ndn::pit::IncomingFace > in = entry->GetIncoming ();
        for (std::set<ndn::pit::IncomingFace>::iterator it=in.begin(); it!=in.end(); ++it)
          {
             count[it->m_face->GetId()]++;             
          }
    }

  for (uint32_t i=0; i< node->GetNDevices(); i++){
  std::cout << Simulator::Now ().ToDouble (Time::S) << "\t"
            << node->GetId () << "\t"
            << Names::FindName (node) << "\t"
            << i << "\t"
            << count[i] << "\t"
            << pit->GetSize () << "\n";
}


  Simulator::Schedule (next, &CachePollutionExperiment::PeriodicStatsPrinter, this, node, next);
}


CachePollutionExperiment::CachePollutionExperiment ()
	: traceFileName("ifa-controller.txt"), csSize("100"),mul(4),
	traceInterval(1), mitigation(false), normal(false)
{
        
}

void CachePollutionExperiment::CommandSetup (int argc, char **argv)
{
	CommandLine cmd;
	cmd.AddValue ("traceFileName", "traceFileName", traceFileName);
	cmd.AddValue ("csSize", "Size of CS", csSize);
	cmd.AddValue ("mul", "multiplier", mul);
	cmd.AddValue ("traceInterval", "traceInterval", traceInterval);
	cmd.AddValue ("Mitigation", "Mitigation", mitigation);
	cmd.AddValue ("Normal", "Normal", normal);
	cmd.Parse (argc, argv);
}


int main (int argc, char *argv[])
{
	CachePollutionExperiment experiment;
	experiment.CommandSetup (argc,argv);
	experiment.Run ();
	return 0; 
}

void CachePollutionExperiment::Run ()
{
	AnnotatedTopologyReader topologyReader ("", 25);
	topologyReader.SetFileName("src/ndnSIM/examples/topologies/DFN1.txt");
	topologyReader.Read ();
               // Getting containers for the consumer/producer/attacker
  	Ptr<Node> routers[11] = {
                          Names::Find<Node>("R0"), Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6"),
                          Names::Find<Node>("R7"), Names::Find<Node>("R8"),
                          Names::Find<Node>("R9"), Names::Find<Node>("R10")};

  	Ptr<Node> consumers[8] = {Names::Find<Node>("C0"), Names::Find<Node>("C1"), Names::Find<Node>("C2"),
                            Names::Find<Node>("C3"), Names::Find<Node>("C4"),
                            Names::Find<Node>("C5"), Names::Find<Node>("C6"),
                            Names::Find<Node>("C7")};
  	Ptr<Node> producers[6] = {Names::Find<Node>("P0"), Names::Find<Node>("P1"), Names::Find<Node>("P2"),
                            Names::Find<Node>("P3"), Names::Find<Node>("P4"),
                            Names::Find<Node>("P5")};
  	Ptr<Node> attackers[4] = {Names::Find<Node>("A0"), Names::Find<Node>("A1"), Names::Find<Node>("A2"),
                            Names::Find<Node>("A3")};

                  if (consumers[6] == 0 ){
      	
      	NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7");
      	
      	}

		

   	if (consumers[0] == 0 || consumers[1] == 0 || consumers[2] == 0 || consumers[3] == 0
      	|| consumers[4] == 0 || consumers[5] == 0 || consumers[6] == 0 || consumers[7] == 0
      	|| producers[0] == 0 || producers[1] == 0 || producers[2] == 0 || producers[3] == 0
      	|| producers[4] == 0 || producers[5] == 0 || attackers[0] == 0 || attackers[1] == 0 
      	|| attackers[2] == 0 || attackers[3] == 0) {
    	NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7, c8, p1, p2, p3, p4, p5, p6, a1, a2, a3, a4 is missing");
  	}



  	// set up periodic PIT stats printer on node 1
  	std::cout << "Time" << "\t"
            << "NodeId" << "\t"
            << "NodeName" << "\t"
            << "Interface" << "\t"
            << "PITperInterface" << "\t"
            << "NumberOfPitEntries" << "\n";
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[0], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[1], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[2], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[3], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[4], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[5], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[6], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[7], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[8], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[9], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[10], Seconds (1));

	// Install NDN stack on all nodes
	ndn::StackHelper ndnHelper;
	ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute", "Type", "2");
	ndnHelper.SetContentStore ("ns3::ndn::cs::Lru","MaxSize", csSize);
	ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "1200kb");
	ndnHelper.SetDefaultRoutes (true);


	for(int i=0; i<11; i++){
	ndnHelper.Install (routers[i]);
	}
	ndnHelper.SetContentStore ("ns3::ndn::cs::Nocache");
	ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "120000kb");
	for(int i=0; i<8; i++){
	ndnHelper.Install (consumers[i]);
	}

	for(int i=0; i<6; i++){
	ndnHelper.Install (producers[i]);
	}

	for(int i=0; i<4; i++){
	ndnHelper.Install (attackers[i]);
	}

	// Installing global routing interface on all nodes
	ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
	ndnGlobalRoutingHelper.InstallAll ();
	// install application to client 

   	float consumerFreq1[8]={300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0};
   	float consumerFreq2[8]={500.0, 500.0, 500.0, 500.0, 500.0, 500.0, 500.0, 500.0};
 	float attackerFreq1[4]={300.0, 300.0, 300.0, 300.0};
 	float attackerFreq2[4]={500.0, 500.0, 500.0, 500.0};

        if((mitigation==true) && (normal==false)){
  	ndn::AppHelper attackerHelper("ns3::ndn::ControllerClient");
  	attackerHelper.SetAttribute("Frequency", StringValue("1"));                    
  	attackerHelper.SetAttribute("Prefix", StringValue("/controller"));
  	attackerHelper.SetAttribute("StartAt", StringValue("0"));
  	attackerHelper.SetAttribute("StopAt", StringValue("600"));
	for(int i=0; i<11; i++){
  	attackerHelper.Install (routers[i]);
	}
        }

        // configure c1
        ndn::AppHelper consumerHelper1("ns3::ndn::ConsumerCbr");
        consumerHelper1.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper1.SetAttribute("Frequency", DoubleValue (consumerFreq1[0]));
        //consumerHelper1.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[0]));
        consumerHelper1.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper1.SetPrefix("/P1/data");
        ApplicationContainer consumer1 = consumerHelper1.Install(consumers[0]);
        consumer1.Start(Seconds(0));     
        consumer1.Stop(Seconds(600));

        // configure c2
        ndn::AppHelper consumerHelper2("ns3::ndn::ConsumerCbr");
        consumerHelper2.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper2.SetAttribute("Frequency", DoubleValue (consumerFreq1[1]));
        //consumerHelper2.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[1]));
        consumerHelper2.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper2.SetPrefix("/P2/data");
        ApplicationContainer consumer2 = consumerHelper2.Install(consumers[1]);
        consumer2.Start(Seconds(30));     
        consumer2.Stop(Seconds(600));

        // configure c3
        ndn::AppHelper consumerHelper3("ns3::ndn::ConsumerCbr");
        consumerHelper3.SetAttribute("LifeTime", StringValue("4s"));                                                    
         consumerHelper3.SetAttribute("Frequency", DoubleValue (consumerFreq1[2]));
         //consumerHelper3.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[2]));
        consumerHelper3.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper3.SetPrefix("/P3/data");
        ApplicationContainer consumer3 = consumerHelper3.Install(consumers[2]);
        consumer3.Start(Seconds(45));     
        consumer3.Stop(Seconds(600));

        // configure c4
        ndn::AppHelper consumerHelper4("ns3::ndn::ConsumerCbr");
        consumerHelper4.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper4.SetAttribute("Frequency", DoubleValue (consumerFreq1[3]));
        //consumerHelper4.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[3]));
        consumerHelper4.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper4.SetPrefix("/P6/data");
        ApplicationContainer consumer4 = consumerHelper4.Install(consumers[3]);
        consumer4.Start(Seconds(60));     
        consumer4.Stop(Seconds(600));

        // configure c5
        ndn::AppHelper consumerHelper5("ns3::ndn::ConsumerCbr");                                
        consumerHelper5.SetAttribute("Frequency", DoubleValue (consumerFreq1[4]));
        //consumerHelper5.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[4]));
        consumerHelper5.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper5.SetPrefix("/P2/data");
        ApplicationContainer consumer5 = consumerHelper5.Install(consumers[4]);
        consumer5.Start(Seconds(45));     
        consumer5.Stop(Seconds(600));

        ndn::AppHelper consumerHelper51("ns3::ndn::ConsumerCbr");                                 
        consumerHelper51.SetAttribute("Frequency", DoubleValue (consumerFreq1[4]));
        //consumerHelper51.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[4]));
        consumerHelper51.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper51.SetPrefix("/P3/data");
        ApplicationContainer consumer51 = consumerHelper51.Install(consumers[4]);
        consumer51.Start(Seconds(45));     
        consumer51.Stop(Seconds(600));
        
    	// configure c6
        ndn::AppHelper consumerHelper6("ns3::ndn::ConsumerCbr");
        consumerHelper6.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper6.SetAttribute("Frequency", DoubleValue (consumerFreq1[5]));
        //consumerHelper6.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[5]));
        consumerHelper6.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper6.SetPrefix("/P3/data");
        ApplicationContainer consumer6 = consumerHelper6.Install(consumers[5]);
        consumer6.Start(Seconds(75));     
        consumer6.Stop(Seconds(600));



    	// configure c7
        ndn::AppHelper consumerHelper7("ns3::ndn::ConsumerCbr");
        consumerHelper7.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper7.SetAttribute("Frequency", DoubleValue (consumerFreq1[6]));
       // consumerHelper7.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[6]));
        consumerHelper7.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper7.SetPrefix("/P6/data");
        ApplicationContainer consumer7 = consumerHelper7.Install(consumers[6]);
        consumer7.Start(Seconds(105));     
        consumer7.Stop(Seconds(240));
        consumerHelper7.SetPrefix("/P6/data");
        consumer7 = consumerHelper7.Install(consumers[6]);
        consumer7.Start(Seconds(330));     
        consumer7.Stop(Seconds(465));

        ndn::AppHelper consumerHelper71("ns3::ndn::ConsumerCbr");
        consumerHelper71.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper71.SetAttribute("Frequency", DoubleValue (consumerFreq1[6]));
        //consumerHelper71.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[6]));
        consumerHelper71.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper71.SetPrefix("/P4/data");
        ApplicationContainer consumer71 = consumerHelper71.Install(consumers[6]);
        consumer71.Start(Seconds(105));     
        consumer71.Stop(Seconds(240));
        consumerHelper71.SetPrefix("/P4/data");
        consumer71 = consumerHelper71.Install(consumers[6]);
        consumer71.Start(Seconds(330));     
        consumer71.Stop(Seconds(465));
        
        // configure c8
        ndn::AppHelper consumerHelper8("ns3::ndn::ConsumerCbr");
        consumerHelper8.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper8.SetAttribute("Frequency", DoubleValue (consumerFreq1[7]));
        //consumerHelper8.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[7]));
        consumerHelper8.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper8.SetPrefix("/P1/data");
        ApplicationContainer consumer8 = consumerHelper8.Install(consumers[7]);
        consumer8.Start(Seconds(120));     
        consumer8.Stop(Seconds(270));
        consumer8.Start(Seconds(375));     
        consumer8.Stop(Seconds(600));

                     /////////////////////////////////////////////////////////////////////////////////
                     // install attacker app on attacker node a_i to send request to producer p_i //
                     /////////////////////////////////////////////////////////////////////////////////
 
        if(normal==false){
    	// configure a1
        ndn::AppHelper attackerHelper1("ns3::ndn::ConsumerCbr");
        attackerHelper1.SetAttribute("LifeTime", StringValue("4s"));                    
        attackerHelper1.SetAttribute("Frequency", DoubleValue (attackerFreq1[0]*mul));
        //attackerHelper1.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[0]*mul));
        attackerHelper1.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper1.SetPrefix("/P1/notdata");
        ApplicationContainer attacker1 = attackerHelper1.Install(attackers[0]);
        attacker1.Start(Seconds(105));     
        attacker1.Stop(Seconds(240));

        // configure a2
        ndn::AppHelper attackerHelper2("ns3::ndn::ConsumerCbr");
        attackerHelper2.SetAttribute("LifeTime", StringValue("4s"));                                                    
        attackerHelper2.SetAttribute("Frequency", DoubleValue (attackerFreq1[1]*mul));
       // attackerHelper2.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[1]*mul));
        attackerHelper2.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper2.SetPrefix("/");
        ApplicationContainer attacker2 = attackerHelper2.Install(attackers[1]);
       	attacker2.Start(Seconds(330));     
        attacker2.Stop(Seconds(465));

    	// configure a3
        ndn::AppHelper attackerHelper3("ns3::ndn::ConsumerCbr");
        attackerHelper3.SetAttribute("LifeTime", StringValue("4s"));                   
        attackerHelper3.SetAttribute("Frequency", DoubleValue (attackerFreq1[2]*mul));
        //attackerHelper3.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[2]*mul));
        attackerHelper3.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper3.SetPrefix("/P5/notdata");
        ApplicationContainer attacker3 = attackerHelper3.Install(attackers[2]);
        attacker3.Start(Seconds(105));     
        attacker3.Stop(Seconds(240));

        // configure a4
        ndn::AppHelper attackerHelper4("ns3::ndn::ConsumerCbr");
        attackerHelper4.SetAttribute("LifeTime", StringValue("4s"));                    
        attackerHelper4.SetAttribute("Frequency", DoubleValue (attackerFreq1[3]*mul));
        //attackerHelper4.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[3]*mul));
        attackerHelper4.SetAttribute("Randomize", StringValue("exponential"));
        attackerHelper4.SetPrefix("/P6/notdata");
        ApplicationContainer attacker4 = attackerHelper4.Install(attackers[3]);
        attacker4.Start(Seconds(330));     
        attacker4.Stop(Seconds(465));
        }
                     ///////////////////////////////////////////////
                     // install producer app on producer node p_i //
                     ///////////////////////////////////////////////

   	for (uint32_t i = 0; i < 6; i++) {                                                  
      	ndn::AppHelper producerHelper("ns3::ndn::Producer");
    	std::string prefix = "/"+Names::FindName(producers[i]);
   	ndnGlobalRoutingHelper.AddOrigins(prefix, producers[i]);
   	prefix+="/data";
 	producerHelper.SetPrefix(prefix);
  	producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  	ApplicationContainer producer = producerHelper.Install(producers[i]);
	}

        if((mitigation==true) && (normal==false)){
        //Controller publisher attach to producer[5]
  	ndn::AppHelper producerHelper ("ns3::ndn::Producer1");
    	ndnGlobalRoutingHelper.AddOrigins("/controller", producers[5]);
  	producerHelper.SetPrefix ("/controller");
  	producerHelper.SetAttribute ("PayloadSize", StringValue("1024"));
  	producerHelper.SetAttribute ("NumRouters", StringValue("11"));
  	producerHelper.Install (producers[5]); // last node
        }
  	Simulator::Stop (Seconds (601.0));


	// Calculate and install FIBs
	ndn::GlobalRoutingHelper::CalculateRoutes();
	Simulator::Stop(Seconds(601));
	// ndn::CsTracer::InstallAll (traceFileName, Seconds (traceInterval));
        ndn::L3RateTracer::InstallAll(traceFileName, Seconds (traceInterval));
	Simulator::Run();
	Simulator::Destroy();
}
