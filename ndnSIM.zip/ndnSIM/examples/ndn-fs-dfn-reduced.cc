#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include <vector>
// ndn-ifa-feature-selection.cc
using namespace ns3;
class CachePollutionExperiment
{
	public:
		CachePollutionExperiment ();
		void Run ();
		void CommandSetup (int argc, char **argv);
	private:
	void OutInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);
	void InInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);
	void DropInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);                                                 
	void OutData (Ptr<const ndn::Data> data, bool fromCache, Ptr<const ndn::Face> face);
	void InData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face);
	void DropData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face);
	void SatisfiedInterests(Ptr<const ndn::pit::Entry>);
	void TimedOutInterests(Ptr<const ndn::pit::Entry>);
	void initializeStats();
	std::string traceFileName, csSize;
	uint32_t currentRouter;
	double  mul, traceInterval;
	float detectAttack(float input[11]);
	struct statics{
		std::vector<uint32_t> inInterest, outInterest, inData, outData, dropInterest, dropData, inSatisfiedInterests, outSatisfiedInterests;
		std::vector<uint32_t> inTimedOutInterests, outTimedOutInterests;
	}stats[11];
	void PeriodicStatsPrinter ();
	Ptr<Node> routers[11]; 
};


CachePollutionExperiment::CachePollutionExperiment ()
	: traceFileName("cache.txt"), csSize("100"),mul(4),
	traceInterval(1)
{
        
}



void CachePollutionExperiment::initializeStats()
{
	for(uint32_t i=0; i< 11; i++)
        {
		for(uint32_t j=0; j< this->routers[i]->GetNDevices(); j++)
		{
		stats[i].inInterest.push_back(0); 
		stats[i].outInterest.push_back(0); 
		stats[i].inData.push_back(0); 
		stats[i].outData.push_back(0); 
		stats[i].dropInterest.push_back(0); 
		stats[i].dropData.push_back(0);
		stats[i].inSatisfiedInterests.push_back(0);
		stats[i].outSatisfiedInterests.push_back(0);
		stats[i].inTimedOutInterests.push_back(0);
		stats[i].outTimedOutInterests.push_back(0);
		}  
	}
}



float CachePollutionExperiment::detectAttack(float input[10])
{
 //NS_LOG_INFO ("ControllerClient::detectAttack(float input[11])");
 	float iw[10][10],b1[10], b2, lw[10], hid[10], out=0.0, max[10]={2355,2401,1170,865,257,1,865,1170,1701,1701};
	std::ifstream  data, data1, data2, data3;
      	std::string fullPath;
        std::string m_path="/home/naveen/Music/backup/Final/CachePollution/ns-3/src/ndnSIM/examples/topologies/reducedPIT";
        fullPath=m_path+"/iw.csv";
     	data.open(fullPath.c_str());
	for(int i=0; i<10; i++){
       		for(int j=0; j<10; j++)
		{
			data>>iw[i][j];
		}
	        }

        fullPath=m_path+"/lw.csv";
     	data1.open(fullPath.c_str());
	for(int j=0; j<10; j++)
	{
		 data1>>lw[j];
	}
        fullPath=m_path+"/b1.csv";
     	data2.open(fullPath.c_str());
	for(int j=0; j<10; j++)
	{
		 data2>>b1[j];
	}
        fullPath=m_path+"/b2.csv";
     	data3.open(fullPath.c_str());
	data3>>b2;
	for(int i=0; i<10; i++){
  		input[i]/=max[i];
      	//std::cout<<input[k][i]<<" ";
 	}

 	for(int i=0; i<10; i++)
	{
   		hid[i]=0;
   		for(int j=0; j<10; j++)
		{
                 hid[i]=hid[i]+input[j]*iw[i][j];

   		}
	}


  	out=0.0;
  	for(int i=0; i<10; i++)
	{
	   	out+=hid[i]*lw[i];
  	}


        //out=1 / (1 + exp((double) -(out+b2)));

        return out+b2;
        /*
    	if(out>0.51)
	return 1;
	else
	return 0;*/
        
}


void CachePollutionExperiment::PeriodicStatsPrinter ()
{
   bool isAttack;
   double now = Simulator::Now ().ToDouble (Time::S);


	for(uint32_t i=0; i< 11; i++)
        {       
                float input[10]={0.0};
		for(uint32_t j=0; j< routers[i]->GetNDevices(); j++)
		{


   		if( ((((now > 105) && (now < 240))&&(((i==0)&&(j==4))||((i==6)&&(j==2))))|| (((now > 330) && (now < 465)) &&(((i==3)&&(j==4))||((i==8)&&(j==3))))) )
   		{
			isAttack=true;
   		}
   		else
   		{
			isAttack=false;
   		}

               if(((i==0)&&(j>=4))||((i==1)&&(j>=4))||((i==2)&&(j>=5))||((i==3)&&(j>=5))||((i==4)&&(j>=4))||((i==5)&&(j>=6))||((i==6)&&(j>=2))||((i==7)&&(j>=4))||((i==8)&&(j>=3))||((i==9)&&(j>=4))||((i==10)&&(j>=2)))
               {
                input[0]=stats[i].inInterest[j];
		input[1]=stats[i].outInterest[j];
		input[2]=stats[i].inData[j];
		input[3]=stats[i].outData[j];
		input[4]=stats[i].dropInterest[j];
		input[5]=stats[i].dropData[j];
		input[6]=stats[i].inSatisfiedInterests[j];
		input[7]=stats[i].outSatisfiedInterests[j];
		input[8]=stats[i].inTimedOutInterests[j];
		input[9]=stats[i].outTimedOutInterests[j];
		//input[10]=(routers[i]->GetObject<ndn::Pit> ())->GetSize ();

   		std::cout << now << "\t"
			<< Names::FindName (routers[i]) << "\t"
			<< j << "\t"
			<< stats[i].inInterest[j] << "\t"
			<< stats[i].outInterest[j] << "\t"
			<< stats[i].inData[j] << "\t"
			<< stats[i].outData[j] << "\t"
			<< stats[i].dropInterest[j] << "\t"
			<< stats[i].dropData[j] << "\t"
			<< stats[i].inSatisfiedInterests[j] << "\t"
			<< stats[i].outSatisfiedInterests[j] << "\t"
			<< stats[i].inTimedOutInterests[j] << "\t"
			<< stats[i].outTimedOutInterests[j] << "\t"
			<< (routers[i]->GetObject<ndn::Pit> ())->GetSize () << "\t"
			<< isAttack << "\t"
			<< detectAttack(input) << "\n";
                }


		}
	}


	for(uint32_t i=0; i< 11; i++)
        {
		for(uint32_t j=0; j< this->routers[i]->GetNDevices(); j++)
		{
   			stats[i].inInterest[j]=0;
			stats[i].outInterest[j]=0;
			stats[i].inData[j]=0;
			stats[i].outData[j]=0;
			stats[i].dropInterest[j]=0;
			stats[i].dropData[j]=0;
 			stats[i].inSatisfiedInterests[j]=0;
			stats[i].outSatisfiedInterests[j]=0;
			stats[i].inTimedOutInterests[j]=0;
			stats[i].outTimedOutInterests[j]=0;
		}
	}
	Simulator::Schedule (Seconds(traceInterval), &CachePollutionExperiment::PeriodicStatsPrinter, this);
}



void CachePollutionExperiment::CommandSetup (int argc, char **argv)
{
	CommandLine cmd;
	cmd.AddValue ("traceFileName", "traceFileName", traceFileName);
	cmd.AddValue ("traceInterval", "traceInterval", traceInterval);
	cmd.AddValue ("mul", "multiplier", mul);
	cmd.AddValue ("csSize", "Size of CS", csSize);
	cmd.Parse (argc, argv);
}


void CachePollutionExperiment::OutInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].outInterest[face->GetId()]++;
}

void CachePollutionExperiment::InInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].inInterest[face->GetId()]++;
}
void CachePollutionExperiment::DropInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].dropInterest[face->GetId()]++;
}    
                                             
void CachePollutionExperiment::OutData (Ptr<const ndn::Data> data, bool fromCache, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].outData[face->GetId()]++;
}

void CachePollutionExperiment::InData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].inData[face->GetId()]++;
}

void CachePollutionExperiment::DropData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].dropData[face->GetId()]++;
}


void CachePollutionExperiment::SatisfiedInterests(Ptr<const ndn::pit::Entry> entry)
{
 for (ndn::pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].inSatisfiedInterests[i->m_face->GetId()] ++;
    }

  for (ndn::pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].outSatisfiedInterests[i->m_face->GetId()] ++;
    }
}

void CachePollutionExperiment::TimedOutInterests(Ptr<const ndn::pit::Entry> entry)
{
 for (ndn::pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].inTimedOutInterests[i->m_face->GetId()] ++;
    }

  for (ndn::pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].outTimedOutInterests[i->m_face->GetId()] ++;
    }
}




int main (int argc, char *argv[])
{
	CachePollutionExperiment experiment;
	experiment.CommandSetup (argc,argv);
	experiment.Run ();
	return 0; 
}

void CachePollutionExperiment::Run ()
{
	AnnotatedTopologyReader topologyReader ("", 25);
	topologyReader.SetFileName("src/ndnSIM/examples/topologies/DFN1.txt");
	topologyReader.Read ();
               // Getting containers for the consumer/producer/attacker
  	Ptr<Node> routers[11] = {Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6"),
                          Names::Find<Node>("R7"), Names::Find<Node>("R8"),
                          Names::Find<Node>("R9"), Names::Find<Node>("R10"),
                          Names::Find<Node>("R11")};

  	Ptr<Node> consumers[8] = {Names::Find<Node>("C1"), Names::Find<Node>("C2"),
                            Names::Find<Node>("C3"), Names::Find<Node>("C4"),
                            Names::Find<Node>("C5"), Names::Find<Node>("C6"),
                            Names::Find<Node>("C7"), Names::Find<Node>("C8")};
  	Ptr<Node> producers[6] = {Names::Find<Node>("P1"), Names::Find<Node>("P2"),
                            Names::Find<Node>("P3"), Names::Find<Node>("P4"),
                            Names::Find<Node>("P5"), Names::Find<Node>("P6")};
  	Ptr<Node> attackers[4] = {Names::Find<Node>("A1"), Names::Find<Node>("A2"),
                            Names::Find<Node>("A3"), Names::Find<Node>("A4")};

   	if (consumers[0] == 0 || consumers[1] == 0 || consumers[2] == 0 || consumers[3] == 0
      	|| consumers[4] == 0 || consumers[5] == 0 || consumers[6] == 0 || consumers[7] == 0
      	|| producers[0] == 0 || producers[1] == 0 || producers[2] == 0 || producers[3] == 0
      	|| producers[4] == 0 || producers[5] == 0 || attackers[0] == 0 || attackers[1] == 0 
      	|| attackers[2] == 0 || attackers[3] == 0) {
    	NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7, c8, p1, p2, p3, p4, p5, p6, a1, a2, a3, a4 is missing");
  	}

	for(int i=0; i<11; i++){
	this->routers[i]=routers[i];
	}

	initializeStats();                               // initializing stats
	std::cout << "Time" << "\t"
          << "Router" << "\t"
          << "Interface" << "\t"
          << "InInt" << "\t"
          << "OutInt" << "\t"
          << "InData" << "\t"
          << "OutData" << "\t"
          << "DropInt" << "\t"
          << "DropData" << "\t"
          << "InSatisfiedInterests" << "\t"
          << "OutSatisfiedInterests" << "\t"
          << "InTimedOutInterests" << "\t"
          << "OutTimedOutInterests" << "\t"
          << "PITSize" << "\t"
	  << "out" << "\t"
	  << "target" << "\n";
	Simulator::Schedule (Seconds (traceInterval), &CachePollutionExperiment::PeriodicStatsPrinter, this); //printing
	// Install NDN stack on all nodes
	ndn::StackHelper ndnHelper;
	ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute");
	ndnHelper.SetContentStore ("ns3::ndn::cs::Lru","MaxSize", csSize);
	ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "12000kb");

	for(int i=0; i<11; i++){
	ndnHelper.Install (routers[i]);
	}
	ndnHelper.SetContentStore ("ns3::ndn::cs::Nocache");
	for(int i=0; i<8; i++){
	ndnHelper.Install (consumers[i]);
	}

	for(int i=0; i<6; i++){
	ndnHelper.Install (producers[i]);
	}

	for(int i=0; i<4; i++){
	ndnHelper.Install (attackers[i]);
	}

	// Installing global routing interface on all nodes
	ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
	ndnGlobalRoutingHelper.InstallAll ();
	// install application to client 

   	float consumerFreq1[8]={300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0};
   	float consumerFreq2[8]={500.0, 500.0, 500.0, 500.0, 500.0, 500.0, 500.0, 500.0};
 	float attackerFreq1[4]={300.0, 300.0, 300.0, 300.0};
 	float attackerFreq2[4]={500.0, 500.0, 500.0, 500.0};
   
    	// configure c1
        ndn::AppHelper consumerHelper1("ns3::ndn::ConsumerCbrRange");
        consumerHelper1.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper1.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[0]));
        consumerHelper1.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[0]));
        consumerHelper1.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper1.SetPrefix("/P1/data");
        ApplicationContainer consumer1 = consumerHelper1.Install(consumers[0]);
        consumer1.Start(Seconds(0));     
        consumer1.Stop(Seconds(600));

        // configure c2
        ndn::AppHelper consumerHelper2("ns3::ndn::ConsumerCbrRange");
        consumerHelper2.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper2.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[1]));
        consumerHelper2.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[1]));
        consumerHelper2.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper2.SetPrefix("/P2/data");
        ApplicationContainer consumer2 = consumerHelper2.Install(consumers[1]);
        consumer2.Start(Seconds(30));     
        consumer2.Stop(Seconds(600));

        // configure c3
        ndn::AppHelper consumerHelper3("ns3::ndn::ConsumerCbrRange");
        consumerHelper3.SetAttribute("LifeTime", StringValue("4s"));                                                    
         consumerHelper3.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[2]));
         consumerHelper3.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[2]));
        consumerHelper3.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper3.SetPrefix("/P3/data");
        ApplicationContainer consumer3 = consumerHelper3.Install(consumers[2]);
        consumer3.Start(Seconds(45));     
        consumer3.Stop(Seconds(600));

        // configure c4
        ndn::AppHelper consumerHelper4("ns3::ndn::ConsumerCbrRange");
        consumerHelper4.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper4.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[3]));
        consumerHelper4.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[3]));
        consumerHelper4.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper4.SetPrefix("/P6/data");
        ApplicationContainer consumer4 = consumerHelper4.Install(consumers[3]);
        consumer4.Start(Seconds(60));     
        consumer4.Stop(Seconds(600));

        // configure c5
        ndn::AppHelper consumerHelper5("ns3::ndn::ConsumerCbrRange");                                
        consumerHelper5.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[4]));
        consumerHelper5.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[4]));
        consumerHelper5.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper5.SetPrefix("/P2/data");
        ApplicationContainer consumer5 = consumerHelper5.Install(consumers[4]);
        consumer5.Start(Seconds(45));     
        consumer5.Stop(Seconds(600));

        ndn::AppHelper consumerHelper51("ns3::ndn::ConsumerCbrRange");                                 
        consumerHelper51.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[4]));
        consumerHelper51.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[4]));
        consumerHelper51.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper51.SetPrefix("/P3/data");
        ApplicationContainer consumer51 = consumerHelper51.Install(consumers[4]);
        consumer51.Start(Seconds(45));     
        consumer51.Stop(Seconds(600));
        
    	// configure c6
        ndn::AppHelper consumerHelper6("ns3::ndn::ConsumerCbrRange");
        consumerHelper6.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper6.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[5]));
        consumerHelper6.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[5]));
        consumerHelper6.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper6.SetPrefix("/P3/data");
        ApplicationContainer consumer6 = consumerHelper6.Install(consumers[5]);
        consumer6.Start(Seconds(75));     
        consumer6.Stop(Seconds(600));



    	// configure c7
        ndn::AppHelper consumerHelper7("ns3::ndn::ConsumerCbrRange");
        consumerHelper7.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper7.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[6]));
        consumerHelper7.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[6]));
        consumerHelper7.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper7.SetPrefix("/P6/data");
        ApplicationContainer consumer7 = consumerHelper7.Install(consumers[6]);
        consumer7.Start(Seconds(105));     
        consumer7.Stop(Seconds(240));
        consumerHelper7.SetPrefix("/P6/data");
        consumer7 = consumerHelper7.Install(consumers[6]);
        consumer7.Start(Seconds(330));     
        consumer7.Stop(Seconds(465));

        ndn::AppHelper consumerHelper71("ns3::ndn::ConsumerCbrRange");
        consumerHelper71.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper71.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[6]));
        consumerHelper71.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[6]));
        consumerHelper71.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper71.SetPrefix("/P4/data");
        ApplicationContainer consumer71 = consumerHelper71.Install(consumers[6]);
        consumer71.Start(Seconds(105));     
        consumer71.Stop(Seconds(240));
        consumerHelper71.SetPrefix("/P4/data");
        consumer71 = consumerHelper71.Install(consumers[6]);
        consumer71.Start(Seconds(330));     
        consumer71.Stop(Seconds(465));
        
        // configure c8
        ndn::AppHelper consumerHelper8("ns3::ndn::ConsumerCbrRange");
        consumerHelper8.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper8.SetAttribute("FrequencyLow", DoubleValue (consumerFreq1[7]));
        consumerHelper8.SetAttribute("FrequencyHigh", DoubleValue (consumerFreq2[7]));
        consumerHelper8.SetAttribute("Randomize", StringValue("exponential"));
        consumerHelper8.SetPrefix("/P1/data");
        ApplicationContainer consumer8 = consumerHelper8.Install(consumers[7]);
        consumer8.Start(Seconds(120));     
        consumer8.Stop(Seconds(270));
        consumer8.Start(Seconds(375));     
        consumer8.Stop(Seconds(600));

                     /////////////////////////////////////////////////////////////////////////////////
                     // install attacker app on attacker node a_i to send request to producer p_i //
                     /////////////////////////////////////////////////////////////////////////////////
 
    	// configure a1
        ndn::AppHelper attackerHelper1("ns3::ndn::ConsumerCbrRange");
        attackerHelper1.SetAttribute("LifeTime", StringValue("4s"));                    
        attackerHelper1.SetAttribute("FrequencyLow", DoubleValue (attackerFreq1[0]*mul));
        attackerHelper1.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[0]*mul));
        attackerHelper1.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper1.SetPrefix("/P1/notdata");
        ApplicationContainer attacker1 = attackerHelper1.Install(attackers[0]);
        attacker1.Start(Seconds(105));     
        attacker1.Stop(Seconds(240));

        // configure a2
        ndn::AppHelper attackerHelper2("ns3::ndn::ConsumerCbrRange");
        attackerHelper2.SetAttribute("LifeTime", StringValue("4s"));                                                    
        attackerHelper2.SetAttribute("FrequencyLow", DoubleValue (attackerFreq1[1]*mul));
        attackerHelper2.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[1]*mul));
        attackerHelper2.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper2.SetPrefix("/P2/notdata");
        ApplicationContainer attacker2 = attackerHelper2.Install(attackers[1]);
       	attacker2.Start(Seconds(330));     
        attacker2.Stop(Seconds(465));

    	// configure a3
        ndn::AppHelper attackerHelper3("ns3::ndn::ConsumerCbrRange");
        attackerHelper3.SetAttribute("LifeTime", StringValue("4s"));                   
        attackerHelper3.SetAttribute("FrequencyLow", DoubleValue (attackerFreq1[2]*mul));
        attackerHelper3.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[2]*mul));
        attackerHelper3.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper3.SetPrefix("/P5/notdata");
        ApplicationContainer attacker3 = attackerHelper3.Install(attackers[2]);
        attacker3.Start(Seconds(105));     
        attacker3.Stop(Seconds(240));

        // configure a4
        ndn::AppHelper attackerHelper4("ns3::ndn::ConsumerCbrRange");
        attackerHelper4.SetAttribute("LifeTime", StringValue("4s"));                    
        attackerHelper4.SetAttribute("FrequencyLow", DoubleValue (attackerFreq1[3]*mul));
        attackerHelper4.SetAttribute("FrequencyHigh", DoubleValue (attackerFreq2[3]*mul));
        attackerHelper4.SetAttribute("Randomize", StringValue("exponential"));
        attackerHelper4.SetPrefix("/P6/notdata");
        ApplicationContainer attacker4 = attackerHelper4.Install(attackers[3]);
        attacker4.Start(Seconds(330));     
        attacker4.Stop(Seconds(465));

                     ///////////////////////////////////////////////
                     // install producer app on producer node p_i //
                     ///////////////////////////////////////////////

   	for (uint32_t i = 0; i < 6; i++) {                                                  
      	ndn::AppHelper producerHelper("ns3::ndn::Producer");
    	std::string prefix = "/"+Names::FindName(producers[i]);
   	ndnGlobalRoutingHelper.AddOrigins(prefix, producers[i]);
   	prefix+="/data";
 	producerHelper.SetPrefix(prefix);
  	producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  	ApplicationContainer producer = producerHelper.Install(producers[i]);
     			}


	for(uint32_t i=0; i< 11; i++)
        {
	//Connect to traces 
	currentRouter=i;
	Ptr<ndn::ForwardingStrategy> fw = routers[i]->GetObject<ndn::ForwardingStrategy> ();
	fw->TraceConnectWithoutContext ("OutInterests",  MakeCallback (&CachePollutionExperiment::OutInterests, this));
	fw->TraceConnectWithoutContext ("InInterests",   MakeCallback (&CachePollutionExperiment::InInterests, this));
	fw->TraceConnectWithoutContext ("DropInterests", MakeCallback (&CachePollutionExperiment::DropInterests, this));
	fw->TraceConnectWithoutContext ("OutData",  MakeCallback (&CachePollutionExperiment::OutData, this));
	fw->TraceConnectWithoutContext ("InData",   MakeCallback (&CachePollutionExperiment::InData, this));
	fw->TraceConnectWithoutContext ("DropData", MakeCallback (&CachePollutionExperiment::DropData, this));
	fw->TraceConnectWithoutContext ("SatisfiedInterests", MakeCallback (&CachePollutionExperiment::SatisfiedInterests, this));
	fw->TraceConnectWithoutContext ("TimedOutInterests", MakeCallback (&CachePollutionExperiment::TimedOutInterests, this));
	}

	// Calculate and install FIBs
	ndn::GlobalRoutingHelper::CalculateRoutes();
	Simulator::Stop(Seconds(601));
	// ndn::CsTracer::InstallAll (traceFileName, Seconds (traceInterval));
	Simulator::Run();
	Simulator::Destroy();
}
