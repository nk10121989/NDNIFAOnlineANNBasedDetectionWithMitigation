#ifndef CUSTOM_APP_H_
#define CUSTOM_APP_H_

#include "ns3/ndn-app.h"
#include "ns3/channel.h"

namespace ns3 {
class CustomApp : public ndn::App
{
public:
  // register NS-3 type "CustomApp"
  static TypeId
  GetTypeId ();

  CustomApp (); //added by me 

  
  // (overridden from ndn::App) Processing upon start of the application
  virtual void
  StartApplication ();

  // (overridden from ndn::App) Processing when application is stopped
  virtual void
  StopApplication ();

  // (overridden from ndn::App) Callback that will be called when Interest arrives
  virtual void
  OnInterest (Ptr<const ndn::Interest> interest);

  // (overridden from ndn::App) Callback that will be called when Data arrives
  virtual void
  OnData (Ptr<const ndn::Data> contentObject);


  void setIsController(bool isController){isController=m_isController;}
  bool getIsController() {return m_isController;}


  static std::list< Ptr<Node> >
      enumerateNeighbors (Ptr<Node> node)
      {
        std::list< Ptr<Node> > neighbors;

        for (uint32_t deviceId = 0; deviceId < node->GetNDevices (); deviceId ++)
          {
            Ptr<NetDevice> device = node->GetDevice (deviceId);

            // get channel, to which device is connected (a "wire")
            Ptr<Channel> channel = device->GetChannel ();

            for (uint32_t channelDeviceId = 0; channelDeviceId < channel->GetNDevices (); channelDeviceId ++)
              {
                Ptr<NetDevice> channelDevice = channel->GetDevice (channelDeviceId);
                if (channelDevice == device)
                  continue;

                neighbors.push_back (channelDevice->GetNode ());
              }
          }
        return neighbors;
       }

  std::list< Ptr<Node> > neighbors;
  private:
  void
  SendInterest ();
};

}
#endif 
