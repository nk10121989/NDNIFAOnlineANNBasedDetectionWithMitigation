#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#define MAXROUTERS 8
// ndn-ifa-controller-simple.cc
using namespace ns3;
class CachePollutionExperiment
{
	public:
		CachePollutionExperiment ();
		void Run ();
		void CommandSetup (int argc, char **argv);
	private:
	void SatisfiedInterests(Ptr<const ndn::pit::Entry>);
	void TimedOutInterests(Ptr<const ndn::pit::Entry>);
	void DropInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face); 
	void InInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);
	void OutData (Ptr<const ndn::Data> data, bool fromCache, Ptr<const ndn::Face> face);
	void initializeStats();
	std::string traceFileName, csSize;
	uint32_t currentRouter;
	double  mul, traceInterval;
	struct statics{
        uint32_t inInterest, outData, inSatisfiedInterests, inTimedOutInterests;
	};
        std::vector<std::pair< uint16_t, std::pair< uint16_t, std::pair<std::string, statics > > > > stats;
	void PeriodicStatsPrinter ();
	Ptr<Node> routers[MAXROUTERS]; 
};


CachePollutionExperiment::CachePollutionExperiment ()
	: traceFileName("cache.txt"), csSize("100"),mul(4),
	traceInterval(1)
{
        
}



void CachePollutionExperiment::initializeStats()
{

  for(uint16_t i=0; i< MAXROUTERS; i++){
      Ptr<ndn::Fib> fib =routers[i]->GetObject<ndn::Fib> ();
      std::pair< uint16_t, std::pair<std::string, statics > > IntData;
      for(uint16_t j=0; j< this->routers[i]->GetNDevices(); j++)
		{
			std::pair<std::string, statics> prefixData;
  			for (Ptr<ndn::fib::Entry> entry = fib->Begin (); entry != fib->End (); entry = fib->Next (entry))
    			{
			struct statics st;
			st.inInterest=0, st.outData=0, st.inSatisfiedInterests=0, st.inTimedOutInterests=0;
			std::string prefix = entry->GetPrefix().get(0).toUri(); 
			prefixData[prefix]=st;
			//stats.push_back( std::pair< uint16_t, std::pair< uint16_t, std::pair<std::string, statics > > > (i,std::pair< uint16_t, std::pair<std::string, statics > > (j, std::pair<std::string, statics> (prefix, st))));
        		}
			IntData[j]=prefixData;
    		}
  	}
}


void CachePollutionExperiment::PeriodicStatsPrinter ()
{
}



void CachePollutionExperiment::CommandSetup (int argc, char **argv)
{
	CommandLine cmd;
	cmd.AddValue ("traceFileName", "traceFileName", traceFileName);
	cmd.AddValue ("traceInterval", "traceInterval", traceInterval);
	cmd.AddValue ("mul", "multiplier", mul);
	cmd.AddValue ("csSize", "Size of CS", csSize);
	cmd.Parse (argc, argv);
}




void CachePollutionExperiment::InInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
stats[face->GetNode ()->GetId()].second[face->GetId()].second[interest->GetName().get(0).toUri()].inInterest++;
}

void CachePollutionExperiment::DropInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	//stats[face->GetNode ()->GetId()].dropInterest[face->GetId()]++;
}    
                                             
void CachePollutionExperiment::OutData (Ptr<const ndn::Data> data, bool fromCache, Ptr<const ndn::Face> face)
{
	//stats[face->GetNode ()->GetId()].outData[face->GetId()]++;
}



void CachePollutionExperiment::SatisfiedInterests(Ptr<const ndn::pit::Entry> entry)
{
/*
 for (ndn::pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].inSatisfiedInterests[i->m_face->GetId()] ++;
    }

  for (ndn::pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].outSatisfiedInterests[i->m_face->GetId()] ++;
    }
*/
}

void CachePollutionExperiment::TimedOutInterests(Ptr<const ndn::pit::Entry> entry)
{
/*
 for (ndn::pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].inTimedOutInterests[i->m_face->GetId()] ++;
    }

  for (ndn::pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].outTimedOutInterests[i->m_face->GetId()] ++;
    }
*/
}


int main (int argc, char *argv[])
{
	CachePollutionExperiment experiment;
	experiment.CommandSetup (argc,argv);
	experiment.Run ();
	return 0; 
}

void CachePollutionExperiment::Run ()
{
	AnnotatedTopologyReader topologyReader ("", 25);
	topologyReader.SetFileName("src/ndnSIM/examples/topologies/simpleIFA.txt");
	topologyReader.Read ();
               // Getting containers for the consumer/producer/attacker
  	Ptr<Node> routers[8] = {Names::Find<Node>("R0"),Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6"),
                          Names::Find<Node>("R7")};

  	Ptr<Node> consumers[1] = {Names::Find<Node>("C0")};
  	Ptr<Node> producers[1] = {Names::Find<Node>("P0")};
  	Ptr<Node> attackers[1] = {Names::Find<Node>("A0")};

   	if (consumers[0] == 0 || producers[0] == 0 ||attackers[0] == 0) {
    	NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7, c8, p1, p2, p3, p4, p5, p6, a1, a2, a3, a4 is missing");
  	}

	for(int i=0; i<MAXROUTERS; i++){
	this->routers[i]=routers[i];
	}

                               // initializing stats
	std::cout << "Time" << "\t"
          << "Router" << "\t"
          << "Interface" << "\t"
          << "InInt" << "\t"
          << "OutInt" << "\t"
          << "InData" << "\t"
          << "OutData" << "\t"
          << "DropInt" << "\t"
          << "DropData" << "\t"
          << "InSatisfiedInterests" << "\t"
          << "OutSatisfiedInterests" << "\t"
          << "InTimedOutInterests" << "\t"
          << "OutTimedOutInterests" << "\t"
          << "PITSize" << "\t"
	  << "isAttack" << "\n";
	Simulator::Schedule (Seconds (traceInterval), &CachePollutionExperiment::PeriodicStatsPrinter, this); //printing
	// Install NDN stack on all nodes
	ndn::StackHelper ndnHelper;
	ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute");
	ndnHelper.SetContentStore ("ns3::ndn::cs::Lru","MaxSize", csSize);
	ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "12000kb");

	for(int i=0; i<MAXROUTERS; i++){
	ndnHelper.Install (routers[i]);
	}
	ndnHelper.SetContentStore ("ns3::ndn::cs::Nocache");
	ndnHelper.Install (consumers[0]);
	ndnHelper.Install (producers[0]);
	ndnHelper.Install (attackers[0]);


	// Installing global routing interface on all nodes
	ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
	ndnGlobalRoutingHelper.InstallAll ();
	// install application to client 



    	// configure c1
        ndn::AppHelper consumerHelper1("ns3::ndn::ConsumerCbrRange");
        consumerHelper1.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper1.SetAttribute("FrequencyLow", DoubleValue (300));
        consumerHelper1.SetAttribute("FrequencyHigh", DoubleValue (500));
        consumerHelper1.SetAttribute("Randomize", StringValue("uniform"));
        consumerHelper1.SetPrefix("/P1/data");
        ApplicationContainer consumer1 = consumerHelper1.Install(consumers[0]);
        consumer1.Start(Seconds(0));     
        consumer1.Stop(Seconds(300));



                     /////////////////////////////////////////////////////////////////////////////////
                     // install attacker app on attacker node a_i to send request to producer p_i //
                     /////////////////////////////////////////////////////////////////////////////////
 
    	// configure a1
        ndn::AppHelper attackerHelper1("ns3::ndn::ConsumerCbrRange");
        attackerHelper1.SetAttribute("LifeTime", StringValue("4s"));                    
        attackerHelper1.SetAttribute("FrequencyLow", DoubleValue (300*mul));
        attackerHelper1.SetAttribute("FrequencyHigh", DoubleValue (500*mul));
        attackerHelper1.SetAttribute("Randomize", StringValue("uniform"));
        attackerHelper1.SetPrefix("/P1/notdata");
        ApplicationContainer attacker1 = attackerHelper1.Install(attackers[0]);
        attacker1.Start(Seconds(100));     
        attacker1.Stop(Seconds(200));


                     ///////////////////////////////////////////////
                     // install producer app on producer node p_i //
                     ///////////////////////////////////////////////

                                                
      	ndn::AppHelper producerHelper("ns3::ndn::Producer");
   	ndnGlobalRoutingHelper.AddOrigins("/P1", producers[0]);
 	producerHelper.SetPrefix("/P1/data");
  	producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  	ApplicationContainer producer = producerHelper.Install(producers[0]);
        
	for(uint32_t i=0; i< MAXROUTERS; i++)
        {
	//Connect to traces 
	currentRouter=i;
	Ptr<ndn::ForwardingStrategy> fw = routers[i]->GetObject<ndn::ForwardingStrategy> ();
	fw->TraceConnectWithoutContext ("InInterests",   MakeCallback (&CachePollutionExperiment::InInterests, this));
	fw->TraceConnectWithoutContext ("DropInterests", MakeCallback (&CachePollutionExperiment::DropInterests, this));
	fw->TraceConnectWithoutContext ("OutData",  MakeCallback (&CachePollutionExperiment::OutData, this));
	fw->TraceConnectWithoutContext ("SatisfiedInterests", MakeCallback (&CachePollutionExperiment::SatisfiedInterests, this));
	fw->TraceConnectWithoutContext ("TimedOutInterests", MakeCallback (&CachePollutionExperiment::TimedOutInterests, this));
	}

	// Calculate and install FIBs
	ndn::GlobalRoutingHelper::CalculateRoutes();
        initializeStats();

	Simulator::Stop(Seconds(301));
	// ndn::CsTracer::InstallAll (traceFileName, Seconds (traceInterval));
	Simulator::Run();
	Simulator::Destroy();
}
