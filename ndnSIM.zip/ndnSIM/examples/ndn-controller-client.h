#ifndef CONTROLLER_CLIENT_H_
#define CONTROLLER_CLIENT_H_

#include "ndn-app.h"
#include "ns3/ndnSIM/model/ndn-common.h"
#include "ns3/random-variable.h"
#include "ns3/ndn-name.h"
#include "ns3/nstime.h"
#include "ns3/data-rate.h"
#include "ns3/ndn-rtt-estimator.h"

namespace ns3 {
namespace ndn {


class ControllerClient : public App
{
	public:
        //For app
	static TypeId GetTypeId();
    	LcpfUniformAttackerSinglePrefix();
    	void SetPrefixes(std::string p);
	//For detection
	CachePollutionExperiment ();
	void Run ();
	void CommandSetup (int argc, char **argv);
   	protected:
	//For app
    	double              m_frequency; // Frequency of interest packets
    	// Random number generator for content IDs
    	UniformVariable     m_randomSeqId;
    	// Random number generator for inter-interest gaps
    	RandomVariable      m_randomTime;
    	// nonce generator
    	UniformVariable m_randNonce;
    	Time m_startAt;
    	Time m_stopAt;
    	Time m_interestLifeTime;
	Time m_detectionDuration;
    	EventId m_sendEvent;
    	std::string m_p;
    	virtual void StartApplication ();
    	virtual void StopApplication ();
    	/**
     	* \brief Constructs the Interest packet and sends it using a callback to the underlying NDN protocol
     	*/
    	virtual void ScheduleNextPacket ();
    	/**
     	* @brief Actually send packet
     	*/
    	void SendPacket ();
	private:
	//For detection
	void OutInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);
	void InInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);
	void DropInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face);                                                 
	void OutData (Ptr<const ndn::Data> data, bool fromCache, Ptr<const ndn::Face> face);
	void InData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face);
	void DropData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face);
	void SatisfiedInterests(Ptr<const ndn::pit::Entry>);
	void TimedOutInterests(Ptr<const ndn::pit::Entry>);
	void initializeStats();
	bool isAttack;
	double  relativeSetSize, consumerFreq;
	struct statics{
		std::vector<uint32_t> inInterest, outInterest, inData, outData, dropInterest, dropData, inSatisfiedInterests, outSatisfiedInterests;
		std::vector<uint32_t> inTimedOutInterests, outTimedOutInterests;
	}stats;
	void PeriodicStatsPrinter ();
};
} // namespace ndn
} // namespace ns3

#endif
