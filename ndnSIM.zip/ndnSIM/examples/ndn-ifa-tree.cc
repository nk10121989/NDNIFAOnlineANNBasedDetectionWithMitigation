#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include <vector>
// ./waf --run "ndn-ifa-tree --traceFileName="tree4x.txt" --mul=4 --traceInterval=1"
using namespace ns3;
class CachePollutionExperiment
{
	public:
	CachePollutionExperiment ();
	void Run ();
	void CommandSetup (int argc, char **argv);
	void PeriodicStatsPrinter (Ptr<Node> node, Time next);
	private:
	std::string traceFileName, csSize;
	double  mul, traceInterval;
        bool mitigation, normal;
};





void CachePollutionExperiment::PeriodicStatsPrinter (Ptr<Node> node, Time next)
{
  Ptr<ndn::Pit> pit = node->GetObject<ndn::Pit> ();
   int count[10]={0};
   for (Ptr<ndn::pit::Entry> entry = pit->Begin (); entry != pit->End (); entry = pit->Next (entry))
    {
       std::set< ndn::pit::IncomingFace > in = entry->GetIncoming ();
        for (std::set<ndn::pit::IncomingFace>::iterator it=in.begin(); it!=in.end(); ++it)
          {
             count[it->m_face->GetId()]++;             
          }
    }

  for (uint32_t i=0; i< node->GetNDevices(); i++){
  std::cout << Simulator::Now ().ToDouble (Time::S) << "\t"
            << node->GetId () << "\t"
            << Names::FindName (node) << "\t"
            << i << "\t"
            << count[i] << "\t"
            << pit->GetSize () << "\n";
}


  Simulator::Schedule (next, &CachePollutionExperiment::PeriodicStatsPrinter, this, node, next);
}


CachePollutionExperiment::CachePollutionExperiment ()
	: traceFileName("ifa-controller.txt"), csSize("100"),mul(4),
	traceInterval(1), mitigation(false), normal(false)
{
        
}

void CachePollutionExperiment::CommandSetup (int argc, char **argv)
{
	CommandLine cmd;
	cmd.AddValue ("traceFileName", "traceFileName", traceFileName);
	cmd.AddValue ("csSize", "Size of CS", csSize);
	cmd.AddValue ("mul", "multiplier", mul);
	cmd.AddValue ("traceInterval", "traceInterval", traceInterval);
	cmd.AddValue ("Mitigation", "Mitigation", mitigation);
	cmd.AddValue ("Normal", "Normal", normal);
	cmd.Parse (argc, argv);
}


int main (int argc, char *argv[])
{
	CachePollutionExperiment experiment;
	experiment.CommandSetup (argc,argv);
	experiment.Run ();
	return 0; 
}

void CachePollutionExperiment::Run ()
{
	AnnotatedTopologyReader topologyReader ("", 25);
	topologyReader.SetFileName("src/ndnSIM/examples/topologies/tree.txt");
	topologyReader.Read ();
               // Getting containers for the consumer/producer/attacker
  	Ptr<Node> routers[7] = {Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6"),
                          Names::Find<Node>("R7")};

  	Ptr<Node> consumers[16] = {Names::Find<Node>("C1"), Names::Find<Node>("C2"),
                            Names::Find<Node>("C3"), Names::Find<Node>("C4"),
                            Names::Find<Node>("C5"), Names::Find<Node>("C6"),
                            Names::Find<Node>("C7"), Names::Find<Node>("C8"), Names::Find<Node>("C9"), Names::Find<Node>("C10"),
			    Names::Find<Node>("C11"), Names::Find<Node>("C12"),
                            Names::Find<Node>("C13"), Names::Find<Node>("C14"),
                            Names::Find<Node>("C15"), Names::Find<Node>("C16")};

  	Ptr<Node> producers[2] = {Names::Find<Node>("P1"), Names::Find<Node>("P2")};
  	Ptr<Node> attackers[3] = {Names::Find<Node>("A1"), Names::Find<Node>("A2"),
                            Names::Find<Node>("A3")};

   	if (consumers[0] == 0 || consumers[1] == 0 || consumers[2] == 0 || consumers[3] == 0
      	|| consumers[4] == 0 || consumers[5] == 0 || consumers[6] == 0 || consumers[7] == 0
      	|| producers[0] == 0 || producers[1] == 0|| attackers[0] == 0 || attackers[1] == 0 
      	|| attackers[2] == 0 ) {
    	NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7, c8, p1, p2, p3, p4, p5, p6, a1, a2, a3, a4 is missing");
  	}



  	// set up periodic PIT stats printer on node 1
  	std::cout << "Time" << "\t"
            << "NodeId" << "\t"
            << "NodeName" << "\t"
            << "Interface" << "\t"
            << "PITperInterface" << "\t"
            << "NumberOfPitEntries" << "\n";
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[0], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[1], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[2], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[3], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[4], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[5], Seconds (1));
  	Simulator::Schedule (Seconds (1), &CachePollutionExperiment::PeriodicStatsPrinter, this, routers[6], Seconds (1));

	// Install NDN stack on all nodes
	ndn::StackHelper ndnHelper;
	ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute");
	ndnHelper.SetContentStore ("ns3::ndn::cs::Lru","MaxSize", csSize);
	ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "120kb");
	ndnHelper.SetDefaultRoutes (true);


	for(int i=0; i<7; i++){
	ndnHelper.Install (routers[i]);
	}
	ndnHelper.SetContentStore ("ns3::ndn::cs::Nocache");
	ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "12000kb");
	for(int i=0; i<16; i++){
	ndnHelper.Install (consumers[i]);
	}

	for(int i=0; i<2; i++){
	ndnHelper.Install (producers[i]);
	}

	for(int i=0; i<3; i++){
	ndnHelper.Install (attackers[i]);
	}

	// Installing global routing interface on all nodes
	ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
	ndnGlobalRoutingHelper.InstallAll ();
	// install application to client 

        ndn::AppHelper consumerHelper("ns3::ndn::ConsumerCbr");
        consumerHelper.SetAttribute("LifeTime", StringValue("4s"));                    
        consumerHelper.SetAttribute("Frequency", DoubleValue (100));
        consumerHelper.SetAttribute("Randomize", StringValue("uniform"));
        for(int i=0; i<16; i++)
        {
        consumerHelper.SetPrefix("/P1/data");
        ApplicationContainer consumer = consumerHelper.Install(consumers[i]);
        consumer.Start(Seconds(0));     
        consumer.Stop(Seconds(300));
        }

        for(int i=0; i<16; i++)
        {
        consumerHelper.SetPrefix("/P2/data");
        ApplicationContainer consumer = consumerHelper.Install(consumers[i]);
        consumer.Start(Seconds(0));     
        consumer.Stop(Seconds(300));
        }


        //attackers
        consumerHelper.SetAttribute("Frequency", DoubleValue (100*mul));
        for(int i=0; i<2; i++)
        {
        consumerHelper.SetPrefix("/P1/notData");
        ApplicationContainer consumer = consumerHelper.Install(attackers[i]);
        consumer.Start(Seconds(60));     
        consumer.Stop(Seconds(120));
        }

        for(int i=0; i<2; i++)
        {
        consumerHelper.SetPrefix("/P2/notData");
        ApplicationContainer consumer = consumerHelper.Install(attackers[i]);
        consumer.Start(Seconds(60));     
        consumer.Stop(Seconds(120));
        }


        for(int i=0; i<2; i++)
        {
        consumerHelper.SetPrefix("/P1/notData");
        ApplicationContainer consumer = consumerHelper.Install(attackers[i]);
        consumer.Start(Seconds(180));     
        consumer.Stop(Seconds(240));
        }

        for(int i=0; i<2; i++)
        {
        consumerHelper.SetPrefix("/P2/notData");
        ApplicationContainer consumer = consumerHelper.Install(attackers[i]);
        consumer.Start(Seconds(180));     
        consumer.Stop(Seconds(240));
        }


       
                     ///////////////////////////////////////////////
                     // install producer app on producer node p_i //
                     ///////////////////////////////////////////////

   	for (uint32_t i = 0; i < 2; i++) {                                                  
      	ndn::AppHelper producerHelper("ns3::ndn::Producer");
    	std::string prefix = "/"+Names::FindName(producers[i]);
   	ndnGlobalRoutingHelper.AddOrigins(prefix, producers[i]);
   	prefix+="/data";
 	producerHelper.SetPrefix(prefix);
  	producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  	ApplicationContainer producer = producerHelper.Install(producers[i]);
	}

       


	// Calculate and install FIBs
	ndn::GlobalRoutingHelper::CalculateRoutes();
	Simulator::Stop(Seconds(301));
	// ndn::CsTracer::InstallAll (traceFileName, Seconds (traceInterval));
        ndn::L3RateTracer::InstallAll(traceFileName, Seconds (traceInterval));
	Simulator::Run();
	Simulator::Destroy();
}
