#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"

using namespace ns3;
int 
main (int argc, char *argv[])
{
  // setting default parameters for PointToPoint links and channels
  Config::SetDefault ("ns3::PointToPointNetDevice::DataRate", StringValue ("1Mbps"));
  Config::SetDefault ("ns3::PointToPointChannel::Delay", StringValue ("10ms"));
  Config::SetDefault ("ns3::DropTailQueue::MaxPackets", StringValue ("20"));

  // Read optional command-line parameters (e.g., enable visualizer with ./waf --run=<> --visualize
  CommandLine cmd;
  cmd.Parse (argc, argv);

  // Creating nodes
  NodeContainer consumers, publishers, routers, attackers;
  consumers.Create (1);
  publishers.Create (1);
  routers.Create (4);
  // Connecting nodes using two links
  PointToPointHelper p2p;
  p2p.Install (consumers.Get (0), routers.Get (0));
  p2p.Install (routers.Get (0), routers.Get (1));
  p2p.Install (routers.Get (1), routers.Get (2));
  p2p.Install (routers.Get (2), routers.Get (3));
  p2p.Install (routers.Get (3), publishers.Get (0));
  // Install NDN stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetDefaultRoutes (true);
  ndnHelper.Install(routers);
  
  ndn::StackHelper noCacheHelper;
  noCacheHelper.SetContentStore ("ns3::ndn::cs::Nocache");
  noCacheHelper.SetDefaultRoutes (true);
  noCacheHelper.Install(publishers);
  noCacheHelper.Install(consumers);
  // Installing applications
  ApplicationContainer consumer[1];
  // consumers[0]
  ndn::AppHelper consumerHelper ("ns3::ndn::ConsumerZipfMandelbrot");
  // Consumer will request /prefix/0, /prefix/1, ...
  consumerHelper.SetPrefix ("/a");
  consumerHelper.SetAttribute ("Frequency", StringValue ("10")); // 10 interests a second
  consumer[0] = consumerHelper.Install (consumers.Get (0));
  consumer[0].Start(Seconds(0));     
  consumer[0].Stop(Seconds(100));
  // producers[0]
  ndn::AppHelper producerHelper ("ns3::ndn::Producer");
  // Producer will reply to all requests starting with /prefix
  producerHelper.SetPrefix ("/a");
  producerHelper.SetAttribute ("PayloadSize", StringValue("1024"));
  producerHelper.Install (publishers.Get (0)); // last node

  Simulator::Stop (Seconds (110.0));
  //ndn::AppDelayTracer::InstallAll ("app-delays-trace.txt");


  Simulator::Run ();
  Simulator::Destroy ();

  return 0;
}
