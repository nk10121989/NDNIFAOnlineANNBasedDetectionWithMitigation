
#include "ndn-controller-client.h"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"

#include "ns3/ndn-l3-protocol.h"
#include "ns3/ndn-app-face.h"
#include "ns3/ndn-interest.h"
#include "ns3/ndn-data.h"
#include "ns3/ndn-pit.h"

#include <boost/algorithm/string.hpp>
#include <fstream>
#include "ns3/ndnSIM/utils/ndn-fw-hop-count-tag.h"
#include <vector>

NS_LOG_COMPONENT_DEFINE ("ControllerClient");

namespace ns3 {
namespace ndn {

NS_OBJECT_ENSURE_REGISTERED (ControllerClient);

TypeId ControllerClient::GetTypeId (void)
{
    static TypeId tid = TypeId ("ns3::ndn::ControllerClient")
        .SetGroupName ("Ndn")
        .SetParent<App> ()
        .AddConstructor<ControllerClient> ()

        .AddAttribute ("Frequency", "Frequency of interest packets",
                StringValue ("1.0"),
                MakeDoubleAccessor (&ControllerClient::m_frequency),
                MakeDoubleChecker<double> ())

        .AddAttribute ("LifeTime", "LifeTime for interest packet",
                StringValue ("3s"),
                MakeTimeAccessor (&ControllerClient::m_interestLifeTime),
                MakeTimeChecker ())

        .AddAttribute ("DetectionDuration", "LifeTime for interest packet",
                StringValue ("3s"),
                MakeTimeAccessor (&ControllerClient::m_detectionDuration),
                MakeTimeChecker ())


        .AddAttribute ("Prefix", "Comma-seperated string of prefixes this client can request",
                StringValue ("/google.com"),
                MakeStringAccessor (&ControllerClient::m_p),
                MakeStringChecker ())

        .AddAttribute ("StartAt",
                "When to start the attack. ControllerClients do nothing before.",
                TimeValue (Minutes (10)),
                MakeTimeAccessor (&ControllerClient::m_startAt),
                MakeTimeChecker ())

        .AddAttribute ("StopAt",
                "When to stop the attack. ControllerClients do nothing after.",
                TimeValue (Minutes (20)),
                MakeTimeAccessor (&ControllerClient::m_stopAt),
                MakeTimeChecker ())
        ;
    return tid;
}

ControllerClient::ControllerClient()
{
	initializeStats();
	Ptr<ndn::ForwardingStrategy> fw = GetNode()->GetObject<ndn::ForwardingStrategy> ();
	fw->TraceConnectWithoutContext ("OutInterests",  MakeCallback (&CachePollutionExperiment::OutInterests, this));
	fw->TraceConnectWithoutContext ("InInterests",   MakeCallback (&CachePollutionExperiment::InInterests, this));
	fw->TraceConnectWithoutContext ("DropInterests", MakeCallback (&CachePollutionExperiment::DropInterests, this));
	fw->TraceConnectWithoutContext ("OutData",  MakeCallback (&CachePollutionExperiment::OutData, this));
	fw->TraceConnectWithoutContext ("InData",   MakeCallback (&CachePollutionExperiment::InData, this));
	fw->TraceConnectWithoutContext ("DropData", MakeCallback (&CachePollutionExperiment::DropData, this));
	fw->TraceConnectWithoutContext ("SatisfiedInterests", MakeCallback (&CachePollutionExperiment::SatisfiedInterests, this));
	fw->TraceConnectWithoutContext ("TimedOutInterests", MakeCallback (&CachePollutionExperiment::TimedOutInterests, this));
	Simulator::Schedule (Seconds (m_detectionDuration), &CachePollutionExperiment::PeriodicStatsPrinter, this); //printing
}


void ControllerClient::initializeStats()
{
	
		for(uint32_t i=0; i<GetNode()->GetNDevices(); i++)
		{
		stats.inInterest.push_back(0); 
		stats.outInterest.push_back(0); 
		stats.inData.push_back(0); 
		stats.outData.push_back(0); 
		stats.dropInterest.push_back(0); 
		stats.dropData.push_back(0);
		stats.inSatisfiedInterests.push_back(0);
		stats.outSatisfiedInterests.push_back(0);
		stats.inTimedOutInterests.push_back(0);
		stats.outTimedOutInterests.push_back(0);
		}  
	
}


void ControllerClient::PeriodicStatsPrinter ()
{
   double now = Simulator::Now ().ToDouble (Time::S);

		for(uint32_t j=0; j< GetNode()->GetNDevices(); j++)
		{
   		std::cout << now << "\t"
			<< Names::FindName (routers[j]) << "\t"
			<< j << "\t"
			<< stats.inInterest[j] << "\t"
			<< stats.outInterest[j] << "\t"
			<< stats.inData[j] << "\t"
			<< stats.outData[j] << "\t"
			<< stats.dropInterest[j] << "\t"
			<< stats.dropData[j] << "\t"
			<< stats.inSatisfiedInterests[j] << "\t"
			<< stats.outSatisfiedInterests[j] << "\t"
			<< stats.inTimedOutInterests[j] << "\t"
			<< stats.outTimedOutInterests[j] << "\n";
		}
	
		for(uint32_t j=0; j< GetNode()->GetNDevices(); j++)
		{
   			stats.inInterest[j]=0;
			stats.outInterest[j]=0;
			stats.inData[j]=0;
			stats.outData[j]=0;
			stats.dropInterest[j]=0;
			stats.dropData[j]=0;
 			stats.inSatisfiedInterests[j]=0;
			stats.outSatisfiedInterests[j]=0;
			stats.inTimedOutInterests[j]=0;
			stats.outTimedOutInterests[j]=0;
		}
	
	Simulator::Schedule (Seconds(m_detectionDuration), &ControllerClient::PeriodicStatsPrinter, this);
}



void ControllerClient::OutInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].outInterest[face->GetId()]++;
}

void ControllerClient::InInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].inInterest[face->GetId()]++;
}
void ControllerClient::DropInterests (Ptr<const ndn::Interest> interest, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].dropInterest[face->GetId()]++;
}    
                                             
void ControllerClient::OutData (Ptr<const ndn::Data> data, bool fromCache, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].outData[face->GetId()]++;
}

void ControllerClient::InData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].inData[face->GetId()]++;
}

void ControllerClient::DropData (Ptr<const ndn::Data> data, Ptr<const ndn::Face> face)
{
	stats[face->GetNode ()->GetId()].dropData[face->GetId()]++;
}


void ControllerClient::SatisfiedInterests(Ptr<const ndn::pit::Entry> entry)
{
 for (ndn::pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].inSatisfiedInterests[i->m_face->GetId()] ++;
    }

  for (ndn::pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].outSatisfiedInterests[i->m_face->GetId()] ++;
    }
}

void ControllerClient::TimedOutInterests(Ptr<const ndn::pit::Entry> entry)
{
 for (ndn::pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].inTimedOutInterests[i->m_face->GetId()] ++;
    }

  for (ndn::pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats[i->m_face->GetNode ()->GetId()].outTimedOutInterests[i->m_face->GetId()] ++;
    }
}

void ControllerClient::StartApplication()
{


    NS_LOG_FUNCTION_NOARGS();
    // do base stuff
    App::StartApplication();
    m_randNonce = UniformVariable (0, std::numeric_limits<uint32_t>::max ());
    m_randomSeqId = UniformVariable (m_numberOfContents - ( m_numberOfContents * m_relativeSetSize ) , m_numberOfContents);
    m_randomTime = UniformVariable (0.0, 2 * 1.0 / m_frequency);
    Simulator::Schedule (m_startAt, &ControllerClient::ScheduleNextPacket, this);
    NS_LOG_INFO ("Requesting Interest: ");
}

void ControllerClient::StopApplication () 
{
  NS_LOG_FUNCTION_NOARGS ();
  // cancel periodic packet generation
  Simulator::Cancel (m_sendEvent);
  // cleanup base stuff
  App::StopApplication ();
}

void ControllerClient::ScheduleNextPacket()
{
    NS_LOG_INFO ("ControllerClient::ScheduleNextPacket()");
    if(!m_sendEvent.IsRunning())
        m_sendEvent = Simulator::Schedule (Seconds(m_randomTime.GetValue()), &ControllerClient::SendPacket, this);

}

void ControllerClient::SendPacket ()
{
  NS_LOG_INFO ("ControllerClient::SendPacket ()");

    NS_LOG_FUNCTION (this);

    Ptr<Name> nameWithSequence = Create<Name> (m_p);

    nameWithSequence->appendSeqNum (0);   //constant seq number

    Ptr<Interest> interest = Create<Interest> ();
    interest->SetNonce               (m_randNonce.GetValue ());
    interest->SetName                (nameWithSequence);
    interest->SetInterestLifetime    (m_interestLifeTime);

    NS_LOG_INFO ("Requesting Interest: " << *interest<<"::SEQ::"<<seq<<"::");

    m_transmittedInterests (interest, this, m_face);
    m_face->ReceiveInterest (interest);

    if(Simulator::Now() >= m_stopAt)
    {
        m_active = false;
    }
    else
    {
        ScheduleNextPacket();
    }
}

} // namespace ndn
} // namespace ns3
