#ifndef CONTROLLER_CLIENT_H
#define CONTROLLER_CLIENT_H_

#include "ndn-app.h"
#include "ns3/ndnSIM/model/ndn-common.h"
#include "ns3/random-variable.h"
#include "ns3/ndn-name.h"
#include "ns3/nstime.h"
#include "ns3/data-rate.h"
#include "ns3/ndn-rtt-estimator.h"
#include "ns3/ndn-pit-entry.h"
#include <vector>

namespace ns3 {
namespace ndn {

class ControllerClient : public App
{
	public:
	//For app
    	static TypeId GetTypeId();
	ControllerClient();
	void SetPrefixes(std::string p);
        virtual void OnData (Ptr<const Data> contentObject);
	protected:
	//For app
        uint32_t m_numRouters;
    	double m_frequency; 
    	UniformVariable     m_randomSeqId; // Random number generator for content IDs
    	RandomVariable      m_randomTime;// Random number generator for inter-interest gaps
    	UniformVariable m_randNonce;// nonce generator
    	Time m_startAt;
    	Time m_stopAt;
	Time m_detectionInterval;
    	Time m_interestLifeTime;
    	EventId m_sendEvent;
    	std::string m_p;
    	std::string m_path;
    	virtual void StartApplication ();
    	virtual void StopApplication ();
     	//Constructs the Interest packet and sends it using a callback to the underlying NDN protocol
    	virtual void ScheduleNextPacket ();
     	// @brief Actually send packet
    	void SendPacket ();
    	uint32_t GetNextSeq();
	private:
	//For Detection
	void OutInterests (Ptr<const Interest> interest, Ptr<const Face> face);
	void InInterests (Ptr<const Interest> interest, Ptr<const Face> face);
	void DropInterests (Ptr<const Interest> interest, Ptr<const Face> face);                                                 
	void OutData (Ptr<const Data> data, bool fromCache, Ptr<const Face> face);
	void InData (Ptr<const Data> data, Ptr<const Face> face);
	void DropData (Ptr<const Data> data, Ptr<const Face> face);
	void SatisfiedInterests(Ptr<const pit::Entry>);
	void TimedOutInterests(Ptr<const pit::Entry>);
	void initializeStats();
	double  mul;
	int   max[11];
 	std::vector<uint32_t> isAttack;
	//uint32_t isAttack;
	struct statics{
		std::vector<uint32_t> inInterest, outInterest, inData, outData, dropInterest, dropData, inSatisfiedInterests, outSatisfiedInterests;
		std::vector<uint32_t> inTimedOutInterests, outTimedOutInterests;
                std::map<std::string , std::vector<uint32_t> > numExpiredPrefix;
	}stats;
	void PeriodicStatsPrinter ();
	uint32_t detectAttack(float input[11]);
	//For Neighbur Node
  	std::list< Ptr<Node> > neighbors;
	void  enumerateNeighbors (Ptr<Node> node);
	uint32_t isFirst;
        std::list<std::string> prefixList;
        std::vector<uint16_t> consumerList;

};

} // namespace ndn
} // namespace ns3

#endif
