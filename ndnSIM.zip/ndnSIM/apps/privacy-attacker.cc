// Consumer sends same request packet with no distribution 
#include "ndn-consumer.h"
#include "privacy-attacker.h"
#include "ndn-one-request-consumer.h" // added by me
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"

#include "ns3/ndn-l3-protocol.h"
#include "ns3/ndn-app-face.h"
#include "ns3/ndn-interest.h"
#include "ns3/ndn-data.h"
#include "ns3/ndn-pit.h"

#include <boost/algorithm/string.hpp>
#include <fstream>
#include "ns3/ndnSIM/utils/ndn-fw-hop-count-tag.h"

NS_LOG_COMPONENT_DEFINE ("PrivacyAttacker");

namespace ns3 {
namespace ndn {

NS_OBJECT_ENSURE_REGISTERED (PrivacyAttacker);

TypeId PrivacyAttacker::GetTypeId (void)
{
    static TypeId tid = TypeId ("ns3::ndn::PrivacyAttacker")
        .SetGroupName ("Ndn")
        .SetParent<App> ()
        .AddConstructor<PrivacyAttacker> ()


        .AddAttribute ("LifeTime", "LifeTime for interest packet",
                StringValue ("3s"),
                MakeTimeAccessor (&PrivacyAttacker::m_interestLifeTime),
                MakeTimeChecker ())

        .AddAttribute ("Prefix", "Comma-seperated string of prefixes this client can request",
                StringValue ("/google.com"),
                MakeStringAccessor (&PrivacyAttacker::m_p),
                MakeStringChecker ())


        .AddAttribute ("StartAt",
                "When to start the attack. PrivacyAttackers do nothing before.",
                TimeValue (Minutes (10)),
                MakeTimeAccessor (&PrivacyAttacker::m_startAt),
                MakeTimeChecker ())

        .AddAttribute ("StopAt",
                "When to stop the attack. PrivacyAttackers do nothing after.",
                TimeValue (Minutes (20)),
                MakeTimeAccessor (&PrivacyAttacker::m_stopAt),
                MakeTimeChecker ())

       .AddAttribute ("NumAppCT", "NumAppCT",
                   IntegerValue (0),
                   MakeIntegerAccessor(&PrivacyAttacker::m_numAppCT),
                   MakeIntegerChecker<int32_t>())

        .AddAttribute ("CTStartTime", "Frequency of interest packets",
                StringValue ("1.0"),
                MakeDoubleAccessor (&PrivacyAttacker::m_cTStartTime),
                MakeDoubleChecker<double> ())

        ;
    return tid;
}

PrivacyAttacker::PrivacyAttacker()
{
count=0;

}

void PrivacyAttacker::StartApplication()
{


    NS_LOG_FUNCTION_NOARGS();

    NS_LOG_INFO ("PrivacyAttacker::StartApplication()");
    // do base stuff
    App::StartApplication();
    m_randNonce = UniformVariable (0, std::numeric_limits<uint32_t>::max ());
    Simulator::Schedule (m_startAt, &PrivacyAttacker::ScheduleNextPacket, this);
    NS_LOG_INFO ("Requesting Interest: ");
}

void PrivacyAttacker::StopApplication () // Called at time specified by Stop
{
  NS_LOG_FUNCTION_NOARGS ();

  // cancel periodic packet generation
  Simulator::Cancel (m_sendEvent);

  // cleanup base stuff
  App::StopApplication ();
}

void PrivacyAttacker::ScheduleNextPacket()
{

    Ptr<Application> app;
    Ptr<OneRequestConsumer> app1, prevApp;

    // Compute CT

    if(count==0){
    Ptr<Node> node = this->GetNode();
 
    for (int i=m_numAppCT*2; i<m_numAppCT*3; i++){
          
	if(node->GetApplication(i)!=0){
          app = node->GetApplication(i);
         }
         else{
             NS_LOG_INFO ("Some thing Wrong");
         }
        app1 = app->GetObject<OneRequestConsumer> ();
        NS_LOG_INFO ("Prefix::"<<app1->getPrefix());
        if(app1->hit==false)
        {       
             CTLow = prevApp->receiveTime - Seconds(m_cTStartTime);
	     CTHigh= app1->receiveTime - Seconds(m_cTStartTime);
             NS_LOG_INFO ("PrivacyAttacker::ScheduleNextPacket()::"<<"::NUM::"<<i<<"::"<<"Prefix::"<<app1->getPrefix()<<"::CTLow::"<<CTLow<<"::CTHigh::"<<CTHigh);  
        break;
        }
	prevApp=app1;
    }
      count++;
   }
    //NS_LOG_INFO ("PrivacyAttacker::ScheduleNextPacket()"<<"::CTHigh::"<<CTHigh<<"::CTLow::"<<CTLow);
    if(!m_sendEvent.IsRunning())
        m_sendEvent = Simulator::Schedule (CTHigh, &PrivacyAttacker::SendPacket, this);

}

void PrivacyAttacker::SendPacket ()
{
  NS_LOG_INFO ("PrivacyAttacker::SendPacket ()");

    NS_LOG_FUNCTION (this);

    requestTime=Simulator::Now(); //added by me
    Ptr<Name> nameWithSequence = Create<Name> (m_p);

    //nameWithSequence->appendSeqNum (seq);

    Ptr<Interest> interest = Create<Interest> ();
    interest->SetNonce               (m_randNonce.GetValue ());
    interest->SetName                (nameWithSequence);
    interest->SetInterestLifetime    (m_interestLifeTime);

    NS_LOG_INFO ("Requesting Interest: " << *interest);

    m_transmittedInterests (interest, this, m_face);
    m_face->ReceiveInterest (interest);

    if(Simulator::Now() >= m_stopAt)
    {
        m_active = false;
    }
    else
    {
        ScheduleNextPacket();
    }
}


void
PrivacyAttacker::OnData (Ptr<const Data> data)
{
  if (!m_active) return;

  App::OnData (data); 

  // NS_LOG_FUNCTION (this << data);
    receiveTime = Simulator::Now();
    rtt=Simulator::Now()-requestTime;

    
    if(rtt < 25000000)
    {      hit=true;
           NS_LOG_INFO ("OneRequestConsumer::OnData ()::"<<data->GetName()<<"::Accept data Time::"<<receiveTime<<"::RTT::"<<rtt<<"::HIT");
    }
    else
    {      hit=false;
	           NS_LOG_INFO ("OneRequestConsumer::OnData ()::"<<data->GetName()<<"::Accept data Time::"<<receiveTime <<"::RTT::"<<rtt<<"::MISS");
    }
}



} // namespace ndn
} // namespace ns3
