#include "ndn-consumer.h"
#include "ndn-controller-client.h"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"
#include "ns3/ndn-pit-entry.h"
#include "ns3/ndn-pit.h"
#include "ns3/ndn-forwarding-strategy.h"
#include "ns3/ndn-l3-protocol.h"
#include "ns3/ndn-app-face.h"
#include "ns3/ndn-interest.h"
#include "ns3/ndn-data.h"
#include "ns3/ndn-pit.h"
#include <fstream>
#include <math.h>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <stdio.h>
#include <boost/algorithm/string.hpp>
#include <fstream>
#include "ns3/ndnSIM/utils/ndn-fw-hop-count-tag.h"

NS_LOG_COMPONENT_DEFINE ("ControllerClient");

namespace ns3 {
namespace ndn {

NS_OBJECT_ENSURE_REGISTERED (ControllerClient);

TypeId ControllerClient::GetTypeId (void)
{
    static TypeId tid = TypeId ("ns3::ndn::ControllerClient")
        .SetGroupName ("Ndn")
        .SetParent<App> ()
        .AddConstructor<ControllerClient> ()

        .AddAttribute ("Frequency", "Frequency of interest packets",
                StringValue ("1.0"),
                MakeDoubleAccessor (&ControllerClient::m_frequency),
                MakeDoubleChecker<double> ())

        .AddAttribute ("LifeTime", "LifeTime for interest packet",
                StringValue ("3s"),
                MakeTimeAccessor (&ControllerClient::m_interestLifeTime),
                MakeTimeChecker ())
   	.AddAttribute ("DetectionInterval",
                "When to start the attack. ControllerClients do nothing before.",
                TimeValue (Minutes (10)),
                MakeTimeAccessor (&ControllerClient::m_detectionInterval),
                MakeTimeChecker ())
        .AddAttribute ("Prefix", "Comma-seperated string of prefixes this client can request",
                StringValue ("/google.com"),
                MakeStringAccessor (&ControllerClient::m_p),
                MakeStringChecker ())

        .AddAttribute ("StartAt",
                "When to start the attack. ControllerClients do nothing before.",
                TimeValue (Minutes (10)),
                MakeTimeAccessor (&ControllerClient::m_startAt),
                MakeTimeChecker ())

        .AddAttribute ("StopAt",
                "When to stop the attack. ControllerClients do nothing after.",
                TimeValue (Minutes (20)),
                MakeTimeAccessor (&ControllerClient::m_stopAt),
                MakeTimeChecker ())

     	.AddAttribute ("PathNNDetector", "Path to directory having all the detector related file",
                StringValue ("/home/naveen/Music/backup/Final/CachePollution/ns-3/src/ndnSIM/examples/topologies/suffled"),
                MakeStringAccessor (&ControllerClient::m_path),
                MakeStringChecker ())

        .AddAttribute ("NumRouters", "Number of routers in scenario",
                   UintegerValue (11),
                   MakeUintegerAccessor (&ControllerClient::m_numRouters),
                   MakeUintegerChecker<uint32_t> ())
        ;
    return tid;
}

ControllerClient::ControllerClient()
{
  //NS_LOG_INFO ("ControllerClient::ControllerClient()");
        for(int j=0; j<11; j++)
	{
		 max[j]=-1;
	} 
	isFirst=1; 


}




void ControllerClient::initializeStats()
{
 //NS_LOG_INFO ("ControllerClient::initializeStats()");
  Ptr<Fib> fib =GetNode()->GetObject<Fib> ();

  for (Ptr<ndn::fib::Entry> entry = fib->Begin (); entry != fib->End (); entry = fib->Next (entry))
    {
      std::string prefix = entry->GetPrefix().get(0).toUri(); 
      prefixList.push_back(prefix);
    }
		for(uint32_t j=0; j< GetNode()->GetNDevices(); j++)
		{
		stats.inInterest.push_back(0); 
		stats.outInterest.push_back(0); 
		stats.inData.push_back(0); 
		stats.outData.push_back(0); 
		stats.dropInterest.push_back(0); 
		stats.dropData.push_back(0);
		stats.inSatisfiedInterests.push_back(0);
		stats.outSatisfiedInterests.push_back(0);
		stats.inTimedOutInterests.push_back(0);
		stats.outTimedOutInterests.push_back(0);
		isAttack.push_back(0);
                for (std::list<std::string>::iterator it=prefixList.begin(); it != prefixList.end(); ++it)
                stats.numExpiredPrefix[*it].push_back(0);
		}  
 //NS_LOG_INFO ("ControllerClient::initializeStats()1");
}


void ControllerClient::PeriodicStatsPrinter ()
{

 //NS_LOG_INFO ("ControllerClient::PeriodicStatsPrinter ()");
   float input[10];
		for(uint32_t j=0; j< GetNode()->GetNDevices(); j++)
		{
			input[0]=stats.inInterest[j];
			input[1]=stats.outInterest[j];
			input[2]=stats.inData[j];
			input[3]=stats.outData[j];
			input[4]=stats.dropInterest[j];
			input[5]=stats.dropData[j];
			input[6]=stats.inSatisfiedInterests[j];
			input[7]=stats.outSatisfiedInterests[j];
			input[8]=stats.inTimedOutInterests[j];
			input[9]=stats.outTimedOutInterests[j];
			//input[10]=(GetNode()->GetObject<ndn::Pit> ())->GetSize ();
			isAttack[j]=detectAttack(input);       // attack status 
		}
		
		for(uint32_t j=0; j< GetNode()->GetNDevices(); j++)
		{
   			stats.inInterest[j]=0;
			stats.outInterest[j]=0;
			stats.inData[j]=0;
			stats.outData[j]=0;
			stats.dropInterest[j]=0;
			stats.dropData[j]=0;
 			stats.inSatisfiedInterests[j]=0;
			stats.outSatisfiedInterests[j]=0;
			stats.inTimedOutInterests[j]=0;
			stats.outTimedOutInterests[j]=0;
                        for (std::list<std::string>::iterator it=prefixList.begin(); it != prefixList.end(); ++it)
                        stats.numExpiredPrefix[*it][j]=0;
		}
	// Simulator::Schedule (Seconds(0.1), &ControllerClient::PeriodicStatsPrinter, this);
}



uint32_t ControllerClient::detectAttack(float input[10])
{
  //NS_LOG_INFO ("ControllerClient::detectAttack(float input[11])");
 	float iw[10][10],b1[10], b2, lw[10], hid[10], out=0.0, max[10]={2355,2401,1170,865,257,1,865,1170,1701,1701};
	std::ifstream  data, data1, data2, data3;
      	std::string fullPath;
        std::string m_path="/home/naveen/Music/backup/Final/CachePollution/ns-3/src/ndnSIM/examples/topologies/reducedPIT";
        fullPath=m_path+"/iw.csv";
     	data.open(fullPath.c_str());
	for(int i=0; i<10; i++){
       		for(int j=0; j<10; j++)
		{
			data>>iw[i][j];
		}
	        }

        fullPath=m_path+"/lw.csv";
     	data1.open(fullPath.c_str());
	for(int j=0; j<10; j++)
	{
		 data1>>lw[j];
	}
        fullPath=m_path+"/b1.csv";
     	data2.open(fullPath.c_str());
	for(int j=0; j<10; j++)
	{
		 data2>>b1[j];
	}
        fullPath=m_path+"/b2.csv";
     	data3.open(fullPath.c_str());
	data3>>b2;
	for(int i=0; i<10; i++){
  		input[i]/=max[i];
      	//std::cout<<input[k][i]<<" ";
 	}

 	for(int i=0; i<10; i++)
	{
   		hid[i]=0;
   		for(int j=0; j<10; j++)
		{
                 hid[i]=hid[i]+input[j]*iw[i][j];

   		}
	}


  	out=0.0;
  	for(int i=0; i<10; i++)
	{
	   	out+=hid[i]*lw[i];
  	}


        //out=1 / (1 + exp((double) -(out+b2)));
        out=out+b2;
        //return out;
        
    	if(out>10)
	return 1;
	else
	return 0;
}





void ControllerClient::OutInterests (Ptr<const Interest> interest, Ptr<const Face> face)
{
	stats.outInterest[face->GetId()]++;
}

void ControllerClient::InInterests (Ptr<const Interest> interest, Ptr<const Face> face)
{
	stats.inInterest[face->GetId()]++;
}
void ControllerClient::DropInterests (Ptr<const Interest> interest, Ptr<const Face> face)
{
	stats.dropInterest[face->GetId()]++;
}    
                                             
void ControllerClient::OutData (Ptr<const Data> data, bool fromCache, Ptr<const Face> face)
{
	stats.outData[face->GetId()]++;
}

void ControllerClient::InData (Ptr<const Data> data, Ptr<const Face> face)
{
	stats.inData[face->GetId()]++;
}

void ControllerClient::DropData (Ptr<const Data> data, Ptr<const Face> face)
{
	stats.dropData[face->GetId()]++;
}


void ControllerClient::SatisfiedInterests(Ptr<const pit::Entry> entry)
{
 for (pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats.inSatisfiedInterests[i->m_face->GetId()] ++;
    }

  for (pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats.outSatisfiedInterests[i->m_face->GetId()] ++;
    }
}

void ControllerClient::TimedOutInterests(Ptr<const pit::Entry> entry)
{
    std::string prefix = entry->GetPrefix().get(0).toUri();

 for (pit::Entry::in_container::const_iterator i = entry->GetIncoming ().begin ();
       i != entry->GetIncoming ().end ();
       i++)
    {
      stats.inTimedOutInterests[i->m_face->GetId()] ++;
       stats.numExpiredPrefix[prefix][i->m_face->GetId()]++;

    }

  for (pit::Entry::out_container::const_iterator i = entry->GetOutgoing ().begin ();
       i != entry->GetOutgoing ().end ();
       i++)
    {
      stats.outTimedOutInterests[i->m_face->GetId()] ++;
    }


}


void ControllerClient::StartApplication()
{

    //NS_LOG_INFO ("ControllerClient::StartApplication()");

    //NS_LOG_FUNCTION_NOARGS();
    App::StartApplication();
        
 	
	initializeStats();
	Ptr<ForwardingStrategy> fw = GetNode()->GetObject<ForwardingStrategy> ();
	fw->TraceConnectWithoutContext ("OutInterests",  MakeCallback (&ControllerClient::OutInterests, this));
	fw->TraceConnectWithoutContext ("InInterests",   MakeCallback (&ControllerClient::InInterests, this));
	fw->TraceConnectWithoutContext ("DropInterests", MakeCallback (&ControllerClient::DropInterests, this));
	fw->TraceConnectWithoutContext ("OutData",  MakeCallback (&ControllerClient::OutData, this));
	fw->TraceConnectWithoutContext ("InData",   MakeCallback (&ControllerClient::InData, this));
	fw->TraceConnectWithoutContext ("DropData", MakeCallback (&ControllerClient::DropData, this));
	fw->TraceConnectWithoutContext ("SatisfiedInterests", MakeCallback (&ControllerClient::SatisfiedInterests, this));
	fw->TraceConnectWithoutContext ("TimedOutInterests", MakeCallback (&ControllerClient::TimedOutInterests, this));
	//Simulator::Schedule (Seconds (0.1), &ControllerClient::PeriodicStatsPrinter, this); //printing

    m_randNonce = UniformVariable (0, std::numeric_limits<uint32_t>::max ());
    m_randomSeqId = UniformVariable (0, 10000); //seg num
    m_randomTime = UniformVariable (0.0, 2 * 1.0 / m_frequency);
    Simulator::Schedule (m_startAt, &ControllerClient::ScheduleNextPacket, this);
}

void ControllerClient::StopApplication () // Called at time specified by Stop
{
//NS_LOG_INFO ("ControllerClient::StopApplication ()");
  NS_LOG_FUNCTION_NOARGS ();

  // cancel periodic packet generation
  Simulator::Cancel (m_sendEvent);

  // cleanup base stuff
  App::StopApplication ();
}

void ControllerClient::ScheduleNextPacket()
{
    //NS_LOG_INFO ("ControllerClient::ScheduleNextPacket()");
    if(!m_sendEvent.IsRunning())
        m_sendEvent = Simulator::Schedule (Seconds(m_randomTime.GetValue()), &ControllerClient::SendPacket, this);

}

void ControllerClient::SendPacket ()
{
  //NS_LOG_INFO ("ControllerClient::SendPacket ()");

    NS_LOG_FUNCTION (this);
    PeriodicStatsPrinter();
    std::ostringstream os;
    std::string stats="";
    if(isFirst==0){
    std::string interfaceID, attackStatus; 
    os<<GetNode()->GetId();
    stats=os.str();
    os.str("");
    for(uint32_t j=0; j< GetNode()->GetNDevices(); j++)
    {
        os<<j;
        interfaceID=os.str();
        os.str("");
	os<<isAttack[j];
        attackStatus=os.str();
        os.str("");
        stats=stats+"-"+interfaceID+"-"+attackStatus;
    }
    
    stats="AS-"+stats;  //"AS-5-1"   Syntax "AS-RName-IntName1-AStatus1-IntName2-AStatus2-IntName3-AStatus3-IntName4-AStatus4"
    }
    else{
    uint32_t intNeighbour;
    enumerateNeighbors(GetNode());
     os<<GetNode()->GetId();
     stats=os.str();
     os.str("");
    for (std::list< Ptr<Node> >::iterator it=neighbors.begin(); it!=neighbors.end(); ++it)
    {

     intNeighbour=(*it)->GetId();
     os << intNeighbour;
     stats+="-"+os.str();
     os.str("");
    }
    stats="NE-"+stats;    //"NE-R2R4R5R6"
    isFirst=0;
    }

    Ptr<Name> nameWithSequence = Create<Name> (m_p+"/"+stats);
   // stats="";
    uint32_t seq = GetNextSeq();
    nameWithSequence->appendSeqNum (seq);

    Ptr<Interest> interest = Create<Interest> ();
    interest->SetNonce               (m_randNonce.GetValue ());
    interest->SetName                (nameWithSequence);
    interest->SetInterestLifetime    (m_interestLifeTime);
   // NS_LOG_INFO ("Requesting Interest: " << *interest<<"::SEQ::"<<seq<<"::");
    m_transmittedInterests (interest, this, m_face);
    m_face->ReceiveInterest (interest);

    if(Simulator::Now() >= m_stopAt)
    {
        m_active = false;
    }
    else
    {
        ScheduleNextPacket();
    }
}

uint32_t ControllerClient::GetNextSeq()
{
    //NS_LOG_INFO ("ControllerClient::GetNextSeq()");
    return m_randomSeqId.GetValue();

}


void ControllerClient::enumerateNeighbors (Ptr<Node> node)
      {

        for (uint32_t deviceId = 0; deviceId < node->GetNDevices (); deviceId ++)
          {
            Ptr<NetDevice> device = node->GetDevice (deviceId);

            // get channel, to which device is connected (a "wire")
            Ptr<Channel> channel = device->GetChannel ();

            for (uint32_t channelDeviceId = 0; channelDeviceId < channel->GetNDevices (); channelDeviceId ++)
              {
                Ptr<NetDevice> channelDevice = channel->GetDevice (channelDeviceId);
                if (channelDevice == device)
                  continue;

                neighbors.push_back (channelDevice->GetNode ());
		if(channelDevice->GetNode ()->GetId()> (m_numRouters-1))
                  {
                   consumerList.push_back(deviceId);
                  }
              }
          }
       }

void ControllerClient::OnData (Ptr<const Data> data)
{
  if (!m_active) return;

  App::OnData (data); // tracing inside
 // NS_LOG_FUNCTION (this << data);
 std::string str1 = data->GetName().get(-1).toUri();
  char str[50]; 
  strcpy(str ,str1.c_str());
    if((str[0]=='A') && (str[1]=='D') && (str[2]=='-')){
    NS_LOG_INFO ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
  char *token = strtok(str, "-"); 
     //GetNode()->GetObject<ForwardingStrategy> ()->blockList.clear();
    while (1)
    {
        token = strtok(NULL, "-");
        if(token == NULL)
        {
                break;
        }
       uint16_t interfaceID=atoi(token);

     std::vector<uint16_t> blockedList=GetNode()->GetObject<ForwardingStrategy> ()->blockList;
      uint16_t found = 0;
      for (std::vector<uint16_t> ::iterator it=blockedList.begin(); it!=blockedList.end(); ++it)
      {
        if(*it==interfaceID)
         {
	  found = 1;
           break;
         }
      } 
     if(found==0)
     {
    for (std::vector<uint16_t>::iterator ptr = consumerList.begin(); ptr < consumerList.end(); ptr++)
     {
       if(*ptr==interfaceID)
       {
              NS_LOG_INFO ("ControllerClient::OnData:" << interfaceID);
          GetNode()->GetObject<ForwardingStrategy> ()->blockList.push_back(interfaceID);
       }
      }
     }
    }
}

}

} // namespace ndn
} // namespace ns3
