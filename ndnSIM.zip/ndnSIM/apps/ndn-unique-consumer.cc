// Consumer sends same request packet with no distribution 
#include "ndn-consumer.h"
#include "ndn-unique-consumer.h"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"

#include "ns3/ndn-l3-protocol.h"
#include "ns3/ndn-app-face.h"
#include "ns3/ndn-interest.h"
#include "ns3/ndn-data.h"
#include "ns3/ndn-pit.h"

#include <boost/algorithm/string.hpp>
#include <fstream>
#include "ns3/ndnSIM/utils/ndn-fw-hop-count-tag.h"

NS_LOG_COMPONENT_DEFINE ("UniqueConsumer");

namespace ns3 {
namespace ndn {

NS_OBJECT_ENSURE_REGISTERED (UniqueConsumer);

TypeId UniqueConsumer::GetTypeId (void)
{
    static TypeId tid = TypeId ("ns3::ndn::UniqueConsumer")
        .SetGroupName ("Ndn")
        .SetParent<App> ()
        .AddConstructor<UniqueConsumer> ()

        .AddAttribute ("Frequency", "Frequency of interest packets",
                StringValue ("1.0"),
                MakeDoubleAccessor (&UniqueConsumer::m_frequency),
                MakeDoubleChecker<double> ())

        .AddAttribute ("LifeTime", "LifeTime for interest packet",
                StringValue ("3s"),
                MakeTimeAccessor (&UniqueConsumer::m_interestLifeTime),
                MakeTimeChecker ())

        .AddAttribute ("Prefix", "Comma-seperated string of prefixes this client can request",
                StringValue ("/google.com"),
                MakeStringAccessor (&UniqueConsumer::m_p),
                MakeStringChecker ())


        .AddAttribute ("StartAt",
                "When to start the attack. UniqueConsumers do nothing before.",
                TimeValue (Minutes (10)),
                MakeTimeAccessor (&UniqueConsumer::m_startAt),
                MakeTimeChecker ())

        .AddAttribute ("StopAt",
                "When to stop the attack. UniqueConsumers do nothing after.",
                TimeValue (Minutes (20)),
                MakeTimeAccessor (&UniqueConsumer::m_stopAt),
                MakeTimeChecker ())
        ;
    return tid;
}

UniqueConsumer::UniqueConsumer()
{}

void UniqueConsumer::StartApplication()
{


    NS_LOG_FUNCTION_NOARGS();

    
    // do base stuff
    App::StartApplication();

    m_randNonce = UniformVariable (0, std::numeric_limits<uint32_t>::max ());



    Simulator::Schedule (m_startAt, &UniqueConsumer::ScheduleNextPacket, this);
    NS_LOG_INFO ("Requesting Interest: ");
}

void UniqueConsumer::StopApplication () // Called at time specified by Stop
{
  NS_LOG_FUNCTION_NOARGS ();

  // cancel periodic packet generation
  Simulator::Cancel (m_sendEvent);

  // cleanup base stuff
  App::StopApplication ();
}

void UniqueConsumer::ScheduleNextPacket()
{
    NS_LOG_INFO ("UniqueConsumer::ScheduleNextPacket()");
    if(!m_sendEvent.IsRunning())
        m_sendEvent = Simulator::Schedule (Seconds(1.0 / m_frequency), &UniqueConsumer::SendPacket, this);

}

void UniqueConsumer::SendPacket ()
{
  NS_LOG_INFO ("UniqueConsumer::SendPacket ()");

    NS_LOG_FUNCTION (this);


    Ptr<Name> nameWithSequence = Create<Name> (m_p);

    //nameWithSequence->appendSeqNum (seq);

    Ptr<Interest> interest = Create<Interest> ();
    interest->SetNonce               (m_randNonce.GetValue ());
    interest->SetName                (nameWithSequence);
    interest->SetInterestLifetime    (m_interestLifeTime);

    NS_LOG_INFO ("Requesting Interest: " << *interest);

    m_transmittedInterests (interest, this, m_face);
    m_face->ReceiveInterest (interest);

    if(Simulator::Now() >= m_stopAt)
    {
        m_active = false;
    }
    else
    {
        ScheduleNextPacket();
    }
}






} // namespace ndn
} // namespace ns3
