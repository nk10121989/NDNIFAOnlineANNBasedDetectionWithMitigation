/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2011 University of California, Los Angeles
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Ilya Moiseenko <iliamo@cs.ucla.edu>
 *         Alexander Afanasyev <alexander.afanasyev@ucla.edu>
 */
#include <iostream>
#include <cstring>
#include <string>
#include <stdio.h>
#include "ndn-producer1.h"
#include "ns3/log.h"
#include "ns3/ndn-interest.h"
#include "ns3/ndn-data.h"
#include "ns3/string.h"
#include "ns3/uinteger.h"
#include "ns3/packet.h"
#include "ns3/simulator.h"

#include "ns3/ndn-app-face.h"
#include "ns3/ndn-fib.h"

#include "ns3/ndnSIM/utils/ndn-fw-hop-count-tag.h"

#include <boost/ref.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>
#include "ns3/ndn-name.h"
namespace ll = boost::lambda;

NS_LOG_COMPONENT_DEFINE ("ndn.Producer1");

namespace ns3 {
namespace ndn {

NS_OBJECT_ENSURE_REGISTERED (Producer1);

TypeId
Producer1::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::ndn::Producer1")
    .SetGroupName ("Ndn")
    .SetParent<App> ()
    .AddConstructor<Producer1> ()
    .AddAttribute ("Prefix","Prefix, for which producer1 has the data",
                   StringValue ("/"),
                   MakeNameAccessor (&Producer1::m_prefix),
                   MakeNameChecker ())
    .AddAttribute ("Postfix", "Postfix that is added to the output data (e.g., for adding producer1-uniqueness)",
                   StringValue ("/"),
                   MakeNameAccessor (&Producer1::m_postfix),
                   MakeNameChecker ())
    .AddAttribute ("PayloadSize", "Virtual payload size for Content packets",
                   UintegerValue (1024),
                   MakeUintegerAccessor (&Producer1::m_virtualPayloadSize),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("Freshness", "Freshness of data packets, if 0, then unlimited freshness",
                   TimeValue (Seconds (0)),
                   MakeTimeAccessor (&Producer1::m_freshness),
                   MakeTimeChecker ())
    .AddAttribute ("Signature", "Fake signature, 0 valid signature (default), other values application-specific",
                   UintegerValue (0),
                   MakeUintegerAccessor (&Producer1::m_signature),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("KeyLocator", "Name to be used for key locator.  If root, then key locator is not used",
                   NameValue (),
                   MakeNameAccessor (&Producer1::m_keyLocator),
                   MakeNameChecker ())
    .AddAttribute ("NumRouters", "Number of routers in scenario",
                   UintegerValue (11),
                   MakeUintegerAccessor (&Producer1::m_numRouters),
                   MakeUintegerChecker<uint32_t> ())
    ;
  return tid;
}

Producer1::Producer1 ()
{
  NS_LOG_INFO("Producer1::Producer1 ()");
    for(uint32_t i; i<m_numRouters; i++){
        neighbourList[i].push_back(0);
  }

  for(uint32_t i; i<m_numRouters; i++){
        attackStatus[i].push_back(0);
  }
}

// inherited from Application base class.
void
Producer1::StartApplication ()
{
  NS_LOG_INFO("Producer1::StartApplication ()");
  NS_LOG_FUNCTION_NOARGS ();
  NS_ASSERT (GetNode ()->GetObject<Fib> () != 0);

  App::StartApplication ();

  NS_LOG_DEBUG ("NodeID: " << GetNode ()->GetId ());

  Ptr<Fib> fib = GetNode ()->GetObject<Fib> ();

  Ptr<fib::Entry> fibEntry = fib->Add (m_prefix, m_face, 0);

  fibEntry->UpdateStatus (m_face, fib::FaceMetric::NDN_FIB_GREEN);

 //Simulator::Schedule (Seconds (5), &Producer1::printNeighbourList, this); 
 //Simulator::Schedule (Seconds (5), &Producer1::printAttackStatus, this); 

  
  // // make face green, so it will be used primarily
  // StaticCast<fib::FibImpl> (fib)->modify (fibEntry,
  //                                        ll::bind (&fib::Entry::UpdateStatus,
  //                                                  ll::_1, m_face, fib::FaceMetric::NDN_FIB_GREEN));
}

void
Producer1::StopApplication ()
{
  NS_LOG_INFO("Producer1::StopApplication ()");
  NS_LOG_FUNCTION_NOARGS ();
  NS_ASSERT (GetNode ()->GetObject<Fib> () != 0);

  App::StopApplication ();
}


void
Producer1::OnInterest (Ptr<const Interest> interest)
{


  App::OnInterest (interest); // tracing inside


  NS_LOG_FUNCTION (this << interest);

  if (!m_active) return;
   uint16_t  routerId;
// received string from controller client 
  std::string str1 = interest->GetName().get(1).toUri(); 
  NS_LOG_INFO("Producer1::OnInterest (Ptr<const Interest> interest) "+str1);
  char str[50]; 
  strcpy(str ,str1.c_str());
  //neighbour details 
  if((str[0]=='N') && (str[1]=='E') && (str[2]=='-'))
  {
    char *token = strtok(str, "-");
    token = strtok(NULL, "-");
    routerId = atoi(token);
    while (1)
    {
        token = strtok(NULL, "-");
        if(token == NULL)
        {
                break;
        }
        neighbourList[routerId].push_back(atoi(token));
    }
  }
   // attack status 
  else
  {
   char *token = strtok(str, "-");
   token = strtok(NULL, "-");
   routerId = atoi(token);
   attackStatus.erase (routerId); 
    while (1)
    {
        token = strtok(NULL, "-");
        if(token == NULL)
        {
                break;
        }
        //uint32_t interfaceID=atoi(token);
        token = strtok(NULL, "-");
        if(token == NULL)
        {
                break;
        }
        uint32_t attack=atoi(token);
        attackStatus[routerId].push_back(attack);
    }
  }

  Name post = detectAttack(routerId);

  Ptr<Data> data = Create<Data> (Create<Packet> (m_virtualPayloadSize));
  Ptr<Name> dataName = Create<Name> (interest->GetName ());
  dataName->append (m_postfix+post);
  data->SetName (dataName);
  data->SetFreshness (m_freshness);
  data->SetTimestamp (Simulator::Now());

  data->SetSignature (m_signature);
  if (m_keyLocator.size () > 0)
    {
      data->SetKeyLocator (Create<Name> (m_keyLocator));
    }


  // Echo back FwHopCountTag if exists
  FwHopCountTag hopCountTag;
  if (interest->GetPayload ()->PeekPacketTag (hopCountTag))
    {
      data->GetPayload ()->AddPacketTag (hopCountTag);
    }

  NS_LOG_INFO("Producer1::OnInterest: Sending data:"+data->GetName().toUri());

  m_face->ReceiveData (data);
  m_transmittedDatas (data, this, m_face);
}

  void Producer1:: printAttackStatus()
   {
    for (std::map<uint32_t, std::vector<uint32_t> >::iterator it=attackStatus.begin(); it!=attackStatus.end(); ++it)
    {
      std::cout << it->first<<":";
     for (std::vector<uint32_t> ::iterator it1=(it->second).begin(); it1!=(it->second).end(); ++it1)
     {
      std::cout << *it1<<"-";
     }
      std::cout <<"\n";
    }

   Simulator::Schedule (Seconds (5), &Producer1::printAttackStatus, this); 
   }


   void Producer1::printNeighbourList()
   {
    for (std::map<uint32_t, std::vector<uint32_t> >::iterator it=neighbourList.begin(); it!=neighbourList.end(); ++it)
    {
      std::cout << it->first<<":";
     for (std::vector<uint32_t> ::iterator it1=(it->second).begin(); it1!=(it->second).end(); ++it1)
     {
      std::cout << *it1<<"-";
     }
      std::cout <<"\n";
    }
    Simulator::Schedule (Seconds (5), &Producer1::printNeighbourList, this); 
   }


Name Producer1::detectAttack(uint16_t routerId)
{
  std::string str="/AD";

  std::ostringstream os;
  uint16_t i=0;
     for (std::vector<uint32_t> ::iterator it=attackStatus[routerId].begin(); it!=attackStatus[routerId].end(); ++it)
     {
      if(*it==1)
      {
         os<<i;
         str=str+"-"+os.str();
         os.str("");
      }
      i++;
     }
  Name post = Name (str);
  return post;
} 

} // namespace ndn
} // namespace ns3
