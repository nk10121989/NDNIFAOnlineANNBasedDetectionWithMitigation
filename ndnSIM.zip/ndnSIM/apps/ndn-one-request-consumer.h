// Consumer sends  ONLY ONE   request packet with no distribution 
#ifndef ONE_REQUEST_CONSUMER_H_
#define ONE_REQUEST_CONSUMER_H_

#include "ndn-app.h"
#include "ns3/ndnSIM/model/ndn-common.h"
#include "ns3/random-variable.h"
#include "ns3/ndn-name.h"
#include "ns3/nstime.h"
#include "ns3/data-rate.h"
#include "ns3/ndn-rtt-estimator.h"

namespace ns3 {
namespace ndn {

class OneRequestConsumer : public App
{
public:
    static TypeId GetTypeId();
    bool hit;
    Time requestTime, rtt, receiveTime; // added by me
    std::string getPrefix(){return m_p;}
    OneRequestConsumer();

    void SetPrefixes(std::string p);
protected:
    double m_frequency;                 // Frequency of interest packets



    // nonce generator
    UniformVariable m_randNonce;

    Time m_startAt;
    Time m_interestLifeTime;
    std::string m_p;

    virtual void StartApplication ();
    virtual void StopApplication ();
  virtual void
  OnData (Ptr<const Data> contentObject);


    /**
     * @brief Actually send packet
     */
    void SendPacket ();



};

} // namespace ndn
} // namespace ns3

#endif
